#!/usr/bin/env python3
import requests
import sys
import json
from datetime import datetime

class BastarGyanAPITester:
        self.base_url = base_url
        self.token = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []

    def log_test(self, name, status, details=""):
        """Log test result"""
        self.tests_run += 1
        if status:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
        
        self.test_results.append({
            "test": name,
            "status": "PASSED" if status else "FAILED",
            "details": details
        })
        return status

    def run_test(self, name, method, endpoint, expected_status, data=None, check_content=None):
        """Run a single API test"""
        url = f"{self.base_url}/api/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'

        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)

            success = response.status_code == expected_status
            details = ""
            
            if success:
                try:
                    response_data = response.json()
                    if check_content:
                        content_check = check_content(response_data)
                        if not content_check:
                            success = False
                            details = "Content validation failed"
                    print(f"   Status: {response.status_code} ✓")
                    if response_data:
                        print(f"   Response sample: {str(response_data)[:100]}...")
                except:
                    response_data = {}
            else:
                details = f"Expected {expected_status}, got {response.status_code}"
                print(f"   Status: {response.status_code} ✗")
                try:
                    error_detail = response.json()
                    details += f" - {error_detail}"
                except:
                    details += f" - {response.text}"

            return self.log_test(name, success, details), response_data if success else {}

        except Exception as e:
            return self.log_test(name, False, f"Exception: {str(e)}"), {}

    def test_root_endpoint(self):
        """Test root API endpoint"""
        return self.run_test(
            "Root API Endpoint",
            "GET", 
            "",
            200,
            check_content=lambda r: "Bastar Gyan" in str(r)
        )

    def test_admin_login_valid(self):
        """Test admin login with valid credentials"""
        success, response = self.run_test(
            "Admin Login - Valid Credentials",
            "POST",
            "admin/login",
            200,
            data={"username": "India2.0", "password": "Bastar12345"},
            check_content=lambda r: "access_token" in r
        )
        if success and 'access_token' in response:
            self.token = response['access_token']
            print(f"   Token obtained: {self.token[:20]}...")
            return True
        return False

    def test_admin_login_invalid(self):
        """Test admin login with invalid credentials"""
        return self.run_test(
            "Admin Login - Invalid Credentials",
            "POST",
            "admin/login",
            401,
            data={"username": "wrong", "password": "wrong"}
        )

    def test_get_classes(self):
        """Test getting all classes"""
        return self.run_test(
            "Get Classes",
            "GET",
            "classes",
            200,
            check_content=lambda r: len(r) >= 3 and any(c["id"] == "10" for c in r)
        )

    def test_get_class_10_subjects(self):
        """Test getting Class 10 subjects (should only have Science and Mathematics)"""
        success, response = self.run_test(
            "Get Class 10 Subjects",
            "GET",
            "subjects/10",
            200
        )
        if success:
            subjects = response if isinstance(response, list) else []
            science_found = any(s.get("name") == "Science" for s in subjects)
            math_found = any(s.get("name") == "Mathematics" for s in subjects)
            
            # Should NOT have separate Physics/Chemistry/Biology for Class 10
            physics_found = any(s.get("name") == "Physics" for s in subjects)
            chemistry_found = any(s.get("name") == "Chemistry" for s in subjects)
            biology_found = any(s.get("name") == "Biology" for s in subjects)
            
            if science_found and math_found and not (physics_found or chemistry_found or biology_found):
                return self.log_test("Class 10 Subject Validation", True, "Science and Mathematics found, no separate Physics/Chemistry/Biology")
            else:
                return self.log_test("Class 10 Subject Validation", False, f"Subjects: {[s.get('name') for s in subjects]}")
        return False

    def test_science_chapters(self):
        """Test Science subject chapters for Class 10"""
        # First get Class 10 subjects
        success, subjects = self.run_test(
            "Get Class 10 Subjects for Chapter Test",
            "GET",
            "subjects/10",
            200
        )
        if success:
            science_subject = next((s for s in subjects if s.get("name") == "Science"), None)
            if science_subject:
                success, chapters = self.run_test(
                    "Get Science Chapters",
                    "GET",
                    f"chapters/{science_subject['id']}",
                    200
                )
                if success:
                    chapter_names = [c.get("name", "") for c in chapters]
                    required_chapters = ["Chemical Reactions", "Electricity"]
                    
                    found_chapters = [ch for ch in required_chapters if any(req in name for name in chapter_names for req in [ch])]
                    
                    if len(found_chapters) >= 1:
                        return self.log_test("Science Chapters Validation", True, f"Found: {found_chapters}")
                    else:
                        return self.log_test("Science Chapters Validation", False, f"Missing required chapters. Found: {chapter_names}")
                        
        return self.log_test("Science Chapters Validation", False, "Could not fetch science chapters")

    def test_admin_endpoints_with_auth(self):
        """Test admin-protected endpoints"""
        if not self.token:
            return self.log_test("Admin Auth Test", False, "No token available")
            
        return self.run_test(
            "Admin Profile Access",
            "GET",
            "admin/me",
            200,
            check_content=lambda r: r.get("username") == "India2.0"
        )

    def test_stats_endpoint(self):
        """Test statistics endpoint"""
        if not self.token:
            return self.log_test("Stats Endpoint Test", False, "No token available")
            
        return self.run_test(
            "Statistics Endpoint",
            "GET",
            "stats",
            200,
            check_content=lambda r: "total_questions" in r and "total_subjects" in r
        )

    def test_search_functionality(self):
        """Test search functionality"""
        return self.run_test(
            "Search Functionality",
            "GET",
            "search?q=chemical&class_id=10",
            200
        )

    def test_seed_demo_data(self):
        """Test seeding demo data (admin required)"""
        if not self.token:
            return self.log_test("Seed Demo Data", False, "No token available")
            
        return self.run_test(
            "Seed Demo Data",
            "POST",
            "seed-demo-data",
            200,
            check_content=lambda r: "seeded" in r
        )

    def print_summary(self):
        """Print test summary"""
        print(f"\n{'='*50}")
        print(f"📊 TEST SUMMARY")
        print(f"{'='*50}")
        print(f"Total Tests: {self.tests_run}")
        print(f"Passed: {self.tests_passed}")
        print(f"Failed: {self.tests_run - self.tests_passed}")
        print(f"Success Rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if self.tests_passed < self.tests_run:
            print(f"\n❌ FAILED TESTS:")
            for result in self.test_results:
                if result["status"] == "FAILED":
                    print(f"   - {result['test']}: {result['details']}")
        
        return self.tests_passed == self.tests_run

def main():
    print("🚀 Starting Bastar Gyan API Tests...")
    print("=" * 50)
    
    tester = BastarGyanAPITester()
    
    # Run tests in order
    tests = [
        tester.test_root_endpoint,
        tester.test_admin_login_invalid,
        tester.test_admin_login_valid,  # This sets the token
        tester.test_get_classes,
        tester.test_get_class_10_subjects,
        tester.test_science_chapters,
        tester.test_admin_endpoints_with_auth,
        tester.test_stats_endpoint,
        tester.test_search_functionality,
        tester.test_seed_demo_data
    ]
    
    for test in tests:
        try:
            test()
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")
            tester.log_test(test.__name__, False, f"Exception: {e}")
    
    # Print final summary
    success = tester.print_summary()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())