# Bastar Gyan - Product Requirements Document

## Original Problem Statement
Create "Bastar Gyan" - an educational website for SAGES (Swami Atmanand Government Excellent Schools) students of Class 10th, 11th, and 12th providing important Q&A, test series/MCQ quiz section with detailed analysis.

## Architecture
- **Frontend**: React.js with Tailwind CSS, Shadcn UI components
- **Backend**: FastAPI (Python)
- **Database**: MongoDB
- **Styling**: Custom design with Tiro Devanagari Hindi & Outfit fonts

## User Personas
1. **Students (10th, 11th, 12th)**: Access Q&A content, take MCQ quizzes with detailed analysis
2. **Admin**: Single authorized admin (India2.0) to manage content

## Core Requirements (Implemented)
- [x] English as primary UI language, bilingual Q&A (English first)
- [x] Class 10 shows Science (combined) and Mathematics only
- [x] Class 11 & 12 show Physics, Chemistry, Biology, Mathematics separately
- [x] New logo branding
- [x] SAGES branding in header and footer
- [x] Test Series prominently in header navigation
- [x] Admin login only (no registration) - Fixed credentials: India2.0 / Bastar12345
- [x] Detailed test analysis with performance breakdown
- [x] Topics to Improve section showing weak areas
- [x] PDF download and WhatsApp share
- [x] Dark mode toggle
- [x] Search functionality

## Class 10 Science Chapters (Combined Physics/Chemistry/Biology)
1. Chemical Reactions and Equations
2. Acids, Bases and Salts
3. Metals and Non-metals
4. Life Processes
5. Control and Coordination
6. Light - Reflection and Refraction
7. Electricity
8. Magnetic Effects of Electric Current

## Admin Credentials
- Username: India2.0
- Password: Bastar12345

## What's Been Implemented (March 2026)
### Updates Applied
- Logo replaced with provided SAGES image
- Footer changed to "Made with ❤️ for SAGES"
- Test Series button highlighted in header
- Admin registration removed for security
- Fixed admin credentials implemented
- Class 10 restructured (Science + Mathematics only)
- Detailed quiz analysis with recommendations
- Topics to Improve section after quiz completion

## P1 Features Remaining
- [ ] Edit existing questions/MCQs
- [ ] Bulk import questions from CSV/Excel
- [ ] Student progress tracking
- [ ] More detailed chapter-wise analysis
