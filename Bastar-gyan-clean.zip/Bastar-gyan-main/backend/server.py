from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timezone
import jwt
import bcrypt
import base64

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Config
SECRET_KEY = os.environ.get('JWT_SECRET', 'bastar-gyan-secret-key-2024')
ALGORITHM = "HS256"

app = FastAPI(title="Bastar Gyan API")
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==================== MODELS ====================

class AdminLogin(BaseModel):
    username: str
    password: str

class AdminCreate(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class SubjectModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    name_hi: str
    class_id: str
    image_url: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ChapterModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    name_hi: str
    subject_id: str
    class_id: str
    order: int = 1
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class QuestionCreate(BaseModel):
    question: str
    question_hi: Optional[str] = None
    answer: str
    answer_hi: Optional[str] = None
    chapter_id: str
    subject_id: str
    class_id: str
    tags: List[str] = []
    images: List[str] = []  # Base64 encoded images

class QuestionModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    question: str
    question_hi: Optional[str] = None
    answer: str
    answer_hi: Optional[str] = None
    chapter_id: str
    subject_id: str
    class_id: str
    tags: List[str] = []
    images: List[str] = []
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MCQOptionModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    text: str
    text_hi: Optional[str] = None

class MCQCreate(BaseModel):
    question: str
    question_hi: Optional[str] = None
    options: List[dict]  # [{text, text_hi}]
    correct_option_index: int
    chapter_id: str
    subject_id: str
    class_id: str
    explanation: Optional[str] = None
    explanation_hi: Optional[str] = None

class MCQModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    question: str
    question_hi: Optional[str] = None
    options: List[dict]
    correct_option_index: int
    chapter_id: str
    subject_id: str
    class_id: str
    explanation: Optional[str] = None
    explanation_hi: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SubjectCreate(BaseModel):
    name: str
    name_hi: str
    class_id: str
    image_url: Optional[str] = None

class ChapterCreate(BaseModel):
    name: str
    name_hi: str
    subject_id: str
    class_id: str
    order: int = 1

# ==================== AUTH HELPERS ====================

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(username: str) -> str:
    payload = {
        "sub": username,
        "exp": datetime.now(timezone.utc).timestamp() + 86400 * 7  # 7 days
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise HTTPException(status_code=401, detail="Invalid token")
        admin = await db.admins.find_one({"username": username}, {"_id": 0})
        if not admin:
            raise HTTPException(status_code=401, detail="Admin not found")
        return username
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ==================== ADMIN ROUTES ====================

# Admin credentials from environment (with fallback for development)
ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'India2.0')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'Bastar12345')

@api_router.post("/admin/login", response_model=TokenResponse)
async def login_admin(data: AdminLogin):
    # Check against fixed credentials
    if data.username == ADMIN_USERNAME and data.password == ADMIN_PASSWORD:
        token = create_token(data.username)
        return TokenResponse(access_token=token)
    raise HTTPException(status_code=401, detail="Invalid credentials")

async def verify_token_fixed(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username or username != ADMIN_USERNAME:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

@api_router.get("/admin/me")
async def get_current_admin(username: str = Depends(verify_token_fixed)):
    return {"username": username}

# ==================== CLASS ROUTES ====================

CLASSES = [
    {"id": "10", "name": "Class 10th", "name_hi": "कक्षा 10वीं"},
    {"id": "11", "name": "Class 11th", "name_hi": "कक्षा 11वीं"},
    {"id": "12", "name": "Class 12th", "name_hi": "कक्षा 12वीं"},
]

@api_router.get("/classes")
async def get_classes():
    return CLASSES

# ==================== SUBJECT ROUTES ====================

@api_router.get("/subjects/{class_id}")
async def get_subjects(class_id: str):
    subjects = await db.subjects.find({"class_id": class_id}, {"_id": 0}).to_list(100)
    return subjects

@api_router.post("/subjects", response_model=dict)
async def create_subject(data: SubjectCreate, username: str = Depends(verify_token_fixed)):
    subject = SubjectModel(**data.model_dump())
    doc = subject.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.subjects.insert_one(doc)
    doc.pop('_id', None)
    return doc

@api_router.delete("/subjects/{subject_id}")
async def delete_subject(subject_id: str, username: str = Depends(verify_token_fixed)):
    result = await db.subjects.delete_one({"id": subject_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Subject not found")
    # Also delete related chapters and questions
    await db.chapters.delete_many({"subject_id": subject_id})
    await db.questions.delete_many({"subject_id": subject_id})
    await db.mcqs.delete_many({"subject_id": subject_id})
    return {"message": "Subject deleted"}

# ==================== CHAPTER ROUTES ====================

@api_router.get("/chapters/{subject_id}")
async def get_chapters(subject_id: str):
    chapters = await db.chapters.find({"subject_id": subject_id}, {"_id": 0}).sort("order", 1).to_list(100)
    return chapters

@api_router.post("/chapters", response_model=dict)
async def create_chapter(data: ChapterCreate, username: str = Depends(verify_token_fixed)):
    chapter = ChapterModel(**data.model_dump())
    doc = chapter.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.chapters.insert_one(doc)
    doc.pop('_id', None)
    return doc

@api_router.delete("/chapters/{chapter_id}")
async def delete_chapter(chapter_id: str, username: str = Depends(verify_token_fixed)):
    result = await db.chapters.delete_one({"id": chapter_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Chapter not found")
    await db.questions.delete_many({"chapter_id": chapter_id})
    await db.mcqs.delete_many({"chapter_id": chapter_id})
    return {"message": "Chapter deleted"}

# ==================== QUESTION ROUTES ====================

@api_router.get("/questions/chapter/{chapter_id}")
async def get_questions_by_chapter(chapter_id: str):
    questions = await db.questions.find({"chapter_id": chapter_id}, {"_id": 0}).to_list(500)
    return questions

@api_router.get("/questions/{question_id}")
async def get_question(question_id: str):
    question = await db.questions.find_one({"id": question_id}, {"_id": 0})
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")
    return question

@api_router.post("/questions", response_model=dict)
async def create_question(data: QuestionCreate, username: str = Depends(verify_token_fixed)):
    question = QuestionModel(**data.model_dump())
    doc = question.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    await db.questions.insert_one(doc)
    doc.pop('_id', None)
    return doc

@api_router.put("/questions/{question_id}", response_model=dict)
async def update_question(question_id: str, data: QuestionCreate, username: str = Depends(verify_token_fixed)):
    existing = await db.questions.find_one({"id": question_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Question not found")
    
    update_data = data.model_dump()
    update_data['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.questions.update_one({"id": question_id}, {"$set": update_data})
    updated = await db.questions.find_one({"id": question_id}, {"_id": 0})
    return updated

@api_router.delete("/questions/{question_id}")
async def delete_question(question_id: str, username: str = Depends(verify_token_fixed)):
    result = await db.questions.delete_one({"id": question_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Question not found")
    return {"message": "Question deleted"}

# ==================== MCQ ROUTES ====================

@api_router.get("/mcqs/chapter/{chapter_id}")
async def get_mcqs_by_chapter(chapter_id: str):
    mcqs = await db.mcqs.find({"chapter_id": chapter_id}, {"_id": 0}).to_list(500)
    return mcqs

@api_router.get("/mcqs/{mcq_id}")
async def get_mcq(mcq_id: str):
    mcq = await db.mcqs.find_one({"id": mcq_id}, {"_id": 0})
    if not mcq:
        raise HTTPException(status_code=404, detail="MCQ not found")
    return mcq

@api_router.post("/mcqs", response_model=dict)
async def create_mcq(data: MCQCreate, username: str = Depends(verify_token_fixed)):
    mcq = MCQModel(**data.model_dump())
    doc = mcq.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.mcqs.insert_one(doc)
    doc.pop('_id', None)
    return doc

@api_router.put("/mcqs/{mcq_id}", response_model=dict)
async def update_mcq(mcq_id: str, data: MCQCreate, username: str = Depends(verify_token_fixed)):
    existing = await db.mcqs.find_one({"id": mcq_id})
    if not existing:
        raise HTTPException(status_code=404, detail="MCQ not found")
    
    update_data = data.model_dump()
    await db.mcqs.update_one({"id": mcq_id}, {"$set": update_data})
    updated = await db.mcqs.find_one({"id": mcq_id}, {"_id": 0})
    return updated

@api_router.delete("/mcqs/{mcq_id}")
async def delete_mcq(mcq_id: str, username: str = Depends(verify_token_fixed)):
    result = await db.mcqs.delete_one({"id": mcq_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="MCQ not found")
    return {"message": "MCQ deleted"}

# ==================== SEARCH ROUTES ====================

@api_router.get("/search")
async def search_questions(q: str, class_id: Optional[str] = None):
    query = {
        "$or": [
            {"question": {"$regex": q, "$options": "i"}},
            {"question_hi": {"$regex": q, "$options": "i"}},
            {"answer": {"$regex": q, "$options": "i"}},
            {"answer_hi": {"$regex": q, "$options": "i"}}
        ]
    }
    if class_id:
        query["class_id"] = class_id
    
    questions = await db.questions.find(query, {"_id": 0}).to_list(50)
    return questions

# ==================== STATS ROUTES ====================

@api_router.get("/stats")
async def get_stats(username: str = Depends(verify_token_fixed)):
    total_questions = await db.questions.count_documents({})
    total_mcqs = await db.mcqs.count_documents({})
    total_subjects = await db.subjects.count_documents({})
    total_chapters = await db.chapters.count_documents({})
    
    return {
        "total_questions": total_questions,
        "total_mcqs": total_mcqs,
        "total_subjects": total_subjects,
        "total_chapters": total_chapters
    }

# ==================== SEED DATA ====================

@api_router.post("/seed-demo-data")
async def seed_demo_data(username: str = Depends(verify_token_fixed)):
    """Seed demo data for testing"""
    
    # Subjects for Class 11 and 12
    subjects_11_12 = [
        {"name": "Physics", "name_hi": "भौतिकी", "image_url": "https://images.unsplash.com/photo-1645323927916-969f9f314ba3?w=400"},
        {"name": "Chemistry", "name_hi": "रसायन विज्ञान", "image_url": "https://images.unsplash.com/photo-1693237396552-91b5d6a9cd2a?w=400"},
        {"name": "Mathematics", "name_hi": "गणित", "image_url": "https://images.unsplash.com/photo-1761058239857-d866c603fafb?w=400"},
        {"name": "Biology", "name_hi": "जीव विज्ञान", "image_url": "https://images.unsplash.com/photo-1698892289193-eb8b082ecce3?w=400"},
    ]
    
    # Subjects for Class 10 (Science combines Physics, Chemistry, Biology)
    subjects_10 = [
        {"name": "Science", "name_hi": "विज्ञान", "image_url": "https://images.unsplash.com/photo-1645323927916-969f9f314ba3?w=400"},
        {"name": "Mathematics", "name_hi": "गणित", "image_url": "https://images.unsplash.com/photo-1761058239857-d866c603fafb?w=400"},
    ]
    
    # Chapters for Class 10 Science (includes Physics, Chemistry, Biology topics)
    science_chapters_10 = [
        {"name": "Chemical Reactions and Equations", "name_hi": "रासायनिक अभिक्रियाएं और समीकरण", "order": 1},
        {"name": "Acids, Bases and Salts", "name_hi": "अम्ल, क्षार और लवण", "order": 2},
        {"name": "Metals and Non-metals", "name_hi": "धातु और अधातु", "order": 3},
        {"name": "Life Processes", "name_hi": "जैव प्रक्रियाएं", "order": 4},
        {"name": "Control and Coordination", "name_hi": "नियंत्रण और समन्वय", "order": 5},
        {"name": "Light - Reflection and Refraction", "name_hi": "प्रकाश - परावर्तन और अपवर्तन", "order": 6},
        {"name": "Electricity", "name_hi": "विद्युत", "order": 7},
        {"name": "Magnetic Effects of Electric Current", "name_hi": "विद्युत धारा के चुंबकीय प्रभाव", "order": 8},
    ]
    
    # Chapters for Class 10 Mathematics
    math_chapters_10 = [
        {"name": "Real Numbers", "name_hi": "वास्तविक संख्याएं", "order": 1},
        {"name": "Polynomials", "name_hi": "बहुपद", "order": 2},
        {"name": "Pair of Linear Equations in Two Variables", "name_hi": "दो चर वाले रैखिक समीकरण युग्म", "order": 3},
        {"name": "Quadratic Equations", "name_hi": "द्विघात समीकरण", "order": 4},
        {"name": "Arithmetic Progressions", "name_hi": "समांतर श्रेढ़ी", "order": 5},
        {"name": "Triangles", "name_hi": "त्रिभुज", "order": 6},
        {"name": "Coordinate Geometry", "name_hi": "निर्देशांक ज्यामिति", "order": 7},
        {"name": "Trigonometry", "name_hi": "त्रिकोणमिति", "order": 8},
    ]
    
    seeded = {"subjects": 0, "chapters": 0, "questions": 0, "mcqs": 0}
    
    for class_data in CLASSES:
        class_id = class_data["id"]
        
        # Choose subjects based on class
        if class_id == "10":
            subjects_to_use = subjects_10
        else:
            subjects_to_use = subjects_11_12
        
        for subj in subjects_to_use:
            # Check if subject exists
            existing_subj = await db.subjects.find_one({"class_id": class_id, "name": subj["name"]})
            if existing_subj:
                subject_id = existing_subj["id"]
            else:
                subject_id = str(uuid.uuid4())
                subject_doc = {
                    "id": subject_id,
                    "name": subj["name"],
                    "name_hi": subj["name_hi"],
                    "class_id": class_id,
                    "image_url": subj["image_url"],
                    "created_at": datetime.now(timezone.utc).isoformat()
                }
                await db.subjects.insert_one(subject_doc)
                seeded["subjects"] += 1
            
            # Choose chapters based on class and subject
            if class_id == "10":
                if subj["name"] == "Science":
                    demo_chapters = science_chapters_10
                else:
                    demo_chapters = math_chapters_10
            else:
                demo_chapters = [
                    {"name": "Chapter 1: Introduction", "name_hi": "अध्याय 1: परिचय", "order": 1},
                    {"name": "Chapter 2: Basic Concepts", "name_hi": "अध्याय 2: मूल अवधारणाएँ", "order": 2},
                    {"name": "Chapter 3: Advanced Topics", "name_hi": "अध्याय 3: उन्नत विषय", "order": 3},
                ]
            
            for chap in demo_chapters:
                existing_chap = await db.chapters.find_one({"subject_id": subject_id, "name": chap["name"]})
                if existing_chap:
                    chapter_id = existing_chap["id"]
                else:
                    chapter_id = str(uuid.uuid4())
                    chapter_doc = {
                        "id": chapter_id,
                        "name": chap["name"],
                        "name_hi": chap["name_hi"],
                        "subject_id": subject_id,
                        "class_id": class_id,
                        "order": chap["order"],
                        "created_at": datetime.now(timezone.utc).isoformat()
                    }
                    await db.chapters.insert_one(chapter_doc)
                    seeded["chapters"] += 1
                
                # Get chapter topic name (handle both formats: "Topic" or "Chapter X: Topic")
                chap_topic = chap['name'].split(':')[-1].strip() if ':' in chap['name'] else chap['name']
                chap_topic_hi = chap['name_hi'].split(':')[-1].strip() if ':' in chap['name_hi'] else chap['name_hi']
                
                # Add demo questions
                existing_q = await db.questions.find_one({"chapter_id": chapter_id})
                if not existing_q:
                    demo_questions = [
                        {
                            "question": f"What is the main concept of {chap_topic}?",
                            "question_hi": f"{chap_topic_hi} की मुख्य अवधारणा क्या है?",
                            "answer": f"This is a detailed explanation about {chap_topic}. It covers fundamental principles and their applications in real-world scenarios.",
                            "answer_hi": f"यह {chap_topic_hi} के बारे में विस्तृत व्याख्या है। यह मूलभूत सिद्धांतों और वास्तविक दुनिया में उनके अनुप्रयोगों को कवर करती है।",
                            "tags": ["IMP 2023", "Repeated"],
                        },
                        {
                            "question": f"Explain the importance of studying {subj['name']}.",
                            "question_hi": f"{subj['name_hi']} का अध्ययन करने का महत्व समझाइए।",
                            "answer": f"Studying {subj['name']} is crucial because it helps us understand the world around us and provides a foundation for technological advancement.",
                            "answer_hi": f"{subj['name_hi']} का अध्ययन महत्वपूर्ण है क्योंकि यह हमें अपने आसपास की दुनिया को समझने में मदद करता है और तकनीकी प्रगति के लिए आधार प्रदान करता है।",
                            "tags": ["IMP 2024"],
                        }
                    ]
                    
                    for q in demo_questions:
                        q_doc = {
                            "id": str(uuid.uuid4()),
                            "question": q["question"],
                            "question_hi": q["question_hi"],
                            "answer": q["answer"],
                            "answer_hi": q["answer_hi"],
                            "chapter_id": chapter_id,
                            "subject_id": subject_id,
                            "class_id": class_id,
                            "tags": q["tags"],
                            "images": [],
                            "created_at": datetime.now(timezone.utc).isoformat(),
                            "updated_at": datetime.now(timezone.utc).isoformat()
                        }
                        await db.questions.insert_one(q_doc)
                        seeded["questions"] += 1
                
                # Add demo MCQs
                existing_mcq = await db.mcqs.find_one({"chapter_id": chapter_id})
                if not existing_mcq:
                    demo_mcqs = [
                        {
                            "question": f"Which of the following best describes {chap_topic}?",
                            "question_hi": f"निम्नलिखित में से कौन {chap_topic_hi} का सबसे अच्छा वर्णन करता है?",
                            "options": [
                                {"text": "Option A: First principle", "text_hi": "विकल्प A: पहला सिद्धांत"},
                                {"text": "Option B: Second principle", "text_hi": "विकल्प B: दूसरा सिद्धांत"},
                                {"text": "Option C: Third principle", "text_hi": "विकल्प C: तीसरा सिद्धांत"},
                                {"text": "Option D: Fourth principle", "text_hi": "विकल्प D: चौथा सिद्धांत"}
                            ],
                            "correct_option_index": 0,
                            "explanation": "Option A is correct because it represents the fundamental concept.",
                            "explanation_hi": "विकल्प A सही है क्योंकि यह मूलभूत अवधारणा को दर्शाता है।"
                        },
                        {
                            "question": f"What is the SI unit commonly used in {subj['name']}?",
                            "question_hi": f"{subj['name_hi']} में आमतौर पर प्रयुक्त SI इकाई क्या है?",
                            "options": [
                                {"text": "Meter", "text_hi": "मीटर"},
                                {"text": "Kilogram", "text_hi": "किलोग्राम"},
                                {"text": "Second", "text_hi": "सेकंड"},
                                {"text": "All of the above", "text_hi": "उपरोक्त सभी"}
                            ],
                            "correct_option_index": 3,
                            "explanation": "All SI units are used depending on the measurement context.",
                            "explanation_hi": "सभी SI इकाइयाँ माप के संदर्भ के अनुसार उपयोग की जाती हैं।"
                        }
                    ]
                    
                    for mcq in demo_mcqs:
                        mcq_doc = {
                            "id": str(uuid.uuid4()),
                            "question": mcq["question"],
                            "question_hi": mcq["question_hi"],
                            "options": mcq["options"],
                            "correct_option_index": mcq["correct_option_index"],
                            "chapter_id": chapter_id,
                            "subject_id": subject_id,
                            "class_id": class_id,
                            "explanation": mcq["explanation"],
                            "explanation_hi": mcq["explanation_hi"],
                            "created_at": datetime.now(timezone.utc).isoformat()
                        }
                        await db.mcqs.insert_one(mcq_doc)
                        seeded["mcqs"] += 1
    
    return {"message": "Demo data seeded successfully", "seeded": seeded}

# ==================== ROOT ====================

@api_router.get("/")
async def root():
    return {"message": "Bastar Gyan API - Educational Platform"}

# Include router and middleware
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
