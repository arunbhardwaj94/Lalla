import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';


export const Footer = () => {
  return (
    <footer className="border-t border-border/50 bg-card mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-2">
            <img 
              src={LOGO_URL} 
              alt="Bastar Gyan Logo" 
              className="h-10 w-auto object-contain"
            />
            <span className="font-heading font-semibold">Bastar Gyan</span>
          </div>

          {/* Links */}
          <nav className="flex items-center gap-6 text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors" data-testid="footer-home">
              Home
            </Link>
            <Link to="/test-series" className="hover:text-foreground transition-colors" data-testid="footer-test">
              Test Series
            </Link>
            <Link to="/admin" className="hover:text-foreground transition-colors" data-testid="footer-admin">
              Admin
            </Link>
          </nav>

          {/* Copyright */}
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-red-500 fill-red-500" /> for SAGES
          </p>
        </div>
      </div>
    </footer>
  );
};
