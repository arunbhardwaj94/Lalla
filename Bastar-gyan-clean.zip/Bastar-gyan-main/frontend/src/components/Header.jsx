import { Link, useNavigate } from 'react-router-dom';
import { Moon, Sun, Search, Menu, X, BookOpen, ClipboardList, Settings } from 'lucide-react';
import { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { cn } from '../lib/utils';


export const Header = () => {
  const { theme, toggleTheme } = useTheme();
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-background/95 border-b border-border/50 shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group" data-testid="header-logo">
          <img 
            src={LOGO_URL} 
            alt="Bastar Gyan Logo" 
            className="h-10 w-auto object-contain group-hover:scale-105 transition-transform"
          />
          <div className="hidden sm:block">
            <h1 className="font-heading text-lg font-bold text-foreground leading-tight">Bastar Gyan</h1>
            <p className="text-xs text-muted-foreground">For SAGES Students</p>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-4">
          <Link 
            to="/" 
            className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2 px-3 py-2"
            data-testid="nav-home"
          >
            <BookOpen className="w-4 h-4" />
            Questions
          </Link>
          
          {/* Test Series - Prominent Button */}
          <Link 
            to="/test-series" 
            className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-2.5 rounded-full hover:from-blue-700 hover:to-blue-600 transition-all flex items-center gap-2 font-semibold shadow-md hover:shadow-lg"
            data-testid="nav-test-series"
          >
            <ClipboardList className="w-4 h-4" />
            Test Series
          </Link>
          
          <Link 
            to="/admin" 
            className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2 px-3 py-2"
            data-testid="nav-admin"
          >
            <Settings className="w-4 h-4" />
            Admin
          </Link>
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <div className={cn(
            "transition-all duration-300 overflow-hidden",
            searchOpen ? "w-64" : "w-0"
          )}>
            <form onSubmit={handleSearch}>
              <Input
                type="text"
                placeholder="Search questions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-9"
                data-testid="search-input"
              />
            </form>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSearchOpen(!searchOpen)}
            className="rounded-full"
            data-testid="search-toggle-btn"
            aria-label="Toggle search"
          >
            {searchOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
          </Button>

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full"
            data-testid="theme-toggle-btn"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-5 h-5 text-amber-400" />
            ) : (
              <Moon className="w-5 h-5" />
            )}
          </Button>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden rounded-full"
            data-testid="mobile-menu-toggle"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border/50 bg-background animate-slide-up">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-2">
            <Link 
              to="/" 
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setMobileMenuOpen(false)}
              data-testid="mobile-nav-home"
            >
              <BookOpen className="w-5 h-5 text-primary" />
              <span>Questions</span>
            </Link>
            
            {/* Test Series - Prominent in Mobile */}
            <Link 
              to="/test-series" 
              className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold"
              onClick={() => setMobileMenuOpen(false)}
              data-testid="mobile-nav-test-series"
            >
              <ClipboardList className="w-5 h-5" />
              <span>Test Series</span>
            </Link>
            
            <Link 
              to="/admin" 
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setMobileMenuOpen(false)}
              data-testid="mobile-nav-admin"
            >
              <Settings className="w-5 h-5 text-primary" />
              <span>Admin Panel</span>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};
