import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { ThemeProvider } from "./context/ThemeContext";
import { AuthProvider } from "./context/AuthContext";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";

// Pages
import HomePage from "./pages/HomePage";
import SubjectsPage from "./pages/SubjectsPage";
import ChaptersPage from "./pages/ChaptersPage";
import QuestionsPage from "./pages/QuestionsPage";
import QuestionDetailPage from "./pages/QuestionDetailPage";
import TestSeriesPage from "./pages/TestSeriesPage";
import QuizPage from "./pages/QuizPage";
import SearchPage from "./pages/SearchPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import AdminDashboard from "./pages/AdminDashboard";
import AddQuestionPage from "./pages/AddQuestionPage";
import AddMCQPage from "./pages/AddMCQPage";
import AddSubjectPage from "./pages/AddSubjectPage";
import AddChapterPage from "./pages/AddChapterPage";

// Management Pages
import ManageQuestionsPage from "./pages/ManageQuestionsPage";
import EditQuestionPage from "./pages/EditQuestionPage";
import ManageMCQsPage from "./pages/ManageMCQsPage";
import EditMCQPage from "./pages/EditMCQPage";
import ManageSubjectsPage from "./pages/ManageSubjectsPage";
import ManageChaptersPage from "./pages/ManageChaptersPage";

// Layout component for public pages
const PublicLayout = ({ children }) => (
  <div className="min-h-screen flex flex-col">
    <Header />
    <main className="flex-1">{children}</main>
    <Footer />
  </div>
);

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-right" richColors />
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<PublicLayout><HomePage /></PublicLayout>} />
            <Route path="/class/:classId" element={<PublicLayout><SubjectsPage /></PublicLayout>} />
            <Route path="/class/:classId/subject/:subjectId" element={<PublicLayout><ChaptersPage /></PublicLayout>} />
            <Route path="/class/:classId/subject/:subjectId/chapter/:chapterId" element={<PublicLayout><QuestionsPage /></PublicLayout>} />
            <Route path="/question/:questionId" element={<PublicLayout><QuestionDetailPage /></PublicLayout>} />
            <Route path="/test-series" element={<PublicLayout><TestSeriesPage /></PublicLayout>} />
            <Route path="/class/:classId/subject/:subjectId/test" element={<PublicLayout><QuizPage /></PublicLayout>} />
            <Route path="/search" element={<PublicLayout><SearchPage /></PublicLayout>} />
            
            {/* Admin Routes */}
            <Route path="/admin" element={<Navigate to="/admin/login" replace />} />
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            
            {/* Admin - Add Content */}
            <Route path="/admin/questions/add" element={<AddQuestionPage />} />
            <Route path="/admin/mcqs/add" element={<AddMCQPage />} />
            <Route path="/admin/subjects/add" element={<AddSubjectPage />} />
            <Route path="/admin/chapters/add" element={<AddChapterPage />} />
            
            {/* Admin - Manage Content */}
            <Route path="/admin/questions" element={<ManageQuestionsPage />} />
            <Route path="/admin/questions/edit/:questionId" element={<EditQuestionPage />} />
            <Route path="/admin/mcqs" element={<ManageMCQsPage />} />
            <Route path="/admin/mcqs/edit/:mcqId" element={<EditMCQPage />} />
            <Route path="/admin/subjects" element={<ManageSubjectsPage />} />
            <Route path="/admin/chapters" element={<ManageChaptersPage />} />
            
            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
