import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { classAPI, subjectAPI, chapterAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';

export default function AddChapterPage() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [name, setName] = useState('');
  const [nameHi, setNameHi] = useState('');
  const [order, setOrder] = useState('1');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchClasses();
    }
  }, [isAuthenticated, authLoading, navigate]);

  useEffect(() => {
    if (selectedClass) {
      fetchSubjects(selectedClass);
      setSelectedSubject('');
    }
  }, [selectedClass]);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const fetchSubjects = async (classId) => {
    try {
      const response = await subjectAPI.getByClass(classId);
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!selectedClass || !selectedSubject) {
      toast.error('Please select class and subject');
      return;
    }
    
    if (!name.trim() || !nameHi.trim()) {
      toast.error('Please enter chapter name in both languages');
      return;
    }

    setLoading(true);
    
    try {
      await chapterAPI.create({
        name: name.trim(),
        name_hi: nameHi.trim(),
        class_id: selectedClass,
        subject_id: selectedSubject,
        order: parseInt(order) || 1
      });
      
      toast.success('Chapter added successfully!');
      navigate('/admin/dashboard');
    } catch (error) {
      console.error('Error creating chapter:', error);
      toast.error('Failed to add chapter');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin/dashboard')} data-testid="back-btn">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Add Chapter</h1>
            <p className="text-muted-foreground">Add a new chapter to a subject</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-card rounded-xl border p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Class</Label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger data-testid="chapter-class-select">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>{cls.name_hi}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Subject</Label>
                <Select value={selectedSubject} onValueChange={setSelectedSubject} disabled={!selectedClass}>
                  <SelectTrigger data-testid="chapter-subject-select">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subj) => (
                      <SelectItem key={subj.id} value={subj.id}>{subj.name_hi}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="chapterNameHi">Chapter Name (Hindi)</Label>
              <Input
                id="chapterNameHi"
                placeholder="अध्याय 1: परिचय..."
                value={nameHi}
                onChange={(e) => setNameHi(e.target.value)}
                data-testid="chapter-name-hi-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="chapterName">Chapter Name (English)</Label>
              <Input
                id="chapterName"
                placeholder="Chapter 1: Introduction..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                data-testid="chapter-name-en-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="order">Order</Label>
              <Input
                id="order"
                type="number"
                min="1"
                placeholder="1"
                value={order}
                onChange={(e) => setOrder(e.target.value)}
                data-testid="chapter-order-input"
              />
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/admin/dashboard')}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading} data-testid="submit-chapter-btn">
              {loading ? 'Adding...' : 'Add Chapter'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
