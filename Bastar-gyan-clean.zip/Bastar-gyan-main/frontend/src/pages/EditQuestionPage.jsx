import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { classAPI, subjectAPI, chapterAPI, questionAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { Skeleton } from '../components/ui/skeleton';
import { toast } from 'sonner';
import { ArrowLeft, Plus, X, Image as ImageIcon } from 'lucide-react';

export default function EditQuestionPage() {
  const { questionId } = useParams();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chapters, setChapters] = useState([]);
  
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedChapter, setSelectedChapter] = useState('');
  
  const [question, setQuestion] = useState('');
  const [questionHi, setQuestionHi] = useState('');
  const [answer, setAnswer] = useState('');
  const [answerHi, setAnswerHi] = useState('');
  const [tags, setTags] = useState([]);
  const [newTag, setNewTag] = useState('');
  const [images, setImages] = useState([]);
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchQuestion();
    }
  }, [isAuthenticated, authLoading, navigate, questionId]);

  const fetchQuestion = async () => {
    try {
      const [questionRes, classesRes] = await Promise.all([
        questionAPI.getById(questionId),
        classAPI.getAll()
      ]);
      
      const qData = questionRes.data;
      setClasses(classesRes.data);
      
      setSelectedClass(qData.class_id);
      setQuestion(qData.question || '');
      setQuestionHi(qData.question_hi || '');
      setAnswer(qData.answer || '');
      setAnswerHi(qData.answer_hi || '');
      setTags(qData.tags || []);
      setImages(qData.images || []);
      
      // Fetch subjects for the class
      const subjectsRes = await subjectAPI.getByClass(qData.class_id);
      setSubjects(subjectsRes.data);
      setSelectedSubject(qData.subject_id);
      
      // Fetch chapters for the subject
      const chaptersRes = await chapterAPI.getBySubject(qData.subject_id);
      setChapters(chaptersRes.data);
      setSelectedChapter(qData.chapter_id);
      
    } catch (error) {
      console.error('Error fetching question:', error);
      toast.error('Failed to load question');
      navigate('/admin/questions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedClass && !loading) {
      fetchSubjects(selectedClass);
    }
  }, [selectedClass]);

  useEffect(() => {
    if (selectedSubject && !loading) {
      fetchChapters(selectedSubject);
    }
  }, [selectedSubject]);

  const fetchSubjects = async (classId) => {
    try {
      const response = await subjectAPI.getByClass(classId);
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchChapters = async (subjectId) => {
    try {
      const response = await chapterAPI.getBySubject(subjectId);
      setChapters(response.data);
    } catch (error) {
      console.error('Error fetching chapters:', error);
    }
  };

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleImageUpload = (e) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setImages(prev => [...prev, event.target.result]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveImage = (index) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!selectedClass || !selectedSubject || !selectedChapter) {
      toast.error('Please select class, subject, and chapter');
      return;
    }
    
    if (!question.trim() && !questionHi.trim()) {
      toast.error('Please enter the question');
      return;
    }
    
    if (!answer.trim() && !answerHi.trim()) {
      toast.error('Please enter the answer');
      return;
    }

    setSaving(true);
    
    try {
      await questionAPI.update(questionId, {
        question: question.trim(),
        question_hi: questionHi.trim(),
        answer: answer.trim(),
        answer_hi: answerHi.trim(),
        class_id: selectedClass,
        subject_id: selectedSubject,
        chapter_id: selectedChapter,
        tags,
        images
      });
      
      toast.success('Question updated successfully!');
      navigate('/admin/questions');
    } catch (error) {
      console.error('Error updating question:', error);
      toast.error('Failed to update question');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Skeleton className="h-8 w-64 mb-8" />
          <Skeleton className="h-96 rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin/questions')} data-testid="back-btn">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Edit Question</h1>
            <p className="text-muted-foreground">Update question details</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Selection */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Location</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Class</Label>
                <Select value={selectedClass} onValueChange={(val) => { setSelectedClass(val); setSelectedSubject(''); setSelectedChapter(''); }}>
                  <SelectTrigger data-testid="edit-class-select">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Subject</Label>
                <Select value={selectedSubject} onValueChange={(val) => { setSelectedSubject(val); setSelectedChapter(''); }} disabled={!selectedClass}>
                  <SelectTrigger data-testid="edit-subject-select">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subj) => (
                      <SelectItem key={subj.id} value={subj.id}>{subj.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Chapter</Label>
                <Select value={selectedChapter} onValueChange={setSelectedChapter} disabled={!selectedSubject}>
                  <SelectTrigger data-testid="edit-chapter-select">
                    <SelectValue placeholder="Select chapter" />
                  </SelectTrigger>
                  <SelectContent>
                    {chapters.map((chap) => (
                      <SelectItem key={chap.id} value={chap.id}>{chap.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Question */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Question</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="question">Question (English)</Label>
                <Textarea
                  id="question"
                  placeholder="Enter question in English..."
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  rows={3}
                  data-testid="edit-question-en-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="questionHi">Question (Hindi)</Label>
                <Textarea
                  id="questionHi"
                  placeholder="प्रश्न हिंदी में लिखें..."
                  value={questionHi}
                  onChange={(e) => setQuestionHi(e.target.value)}
                  rows={3}
                  data-testid="edit-question-hi-input"
                />
              </div>
            </div>
          </div>

          {/* Answer */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Answer</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="answer">Answer (English)</Label>
                <Textarea
                  id="answer"
                  placeholder="Enter answer in English..."
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  rows={6}
                  data-testid="edit-answer-en-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="answerHi">Answer (Hindi)</Label>
                <Textarea
                  id="answerHi"
                  placeholder="उत्तर हिंदी में लिखें..."
                  value={answerHi}
                  onChange={(e) => setAnswerHi(e.target.value)}
                  rows={6}
                  data-testid="edit-answer-hi-input"
                />
              </div>
            </div>
          </div>

          {/* Tags */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Tags</h2>
            <div className="flex flex-wrap gap-2 mb-4">
              {tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="flex items-center gap-1">
                  {tag}
                  <button type="button" onClick={() => handleRemoveTag(tag)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Add tag (e.g., IMP 2023, Repeated)"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                data-testid="edit-tag-input"
              />
              <Button type="button" variant="secondary" onClick={handleAddTag}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Images */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Images / Diagrams</h2>
            <div className="flex flex-wrap gap-4 mb-4">
              {images.map((img, index) => (
                <div key={index} className="relative w-24 h-24 rounded-lg border overflow-hidden">
                  <img src={img} alt={`Upload ${index + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(index)}
                    className="absolute top-1 right-1 w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
            <label className="flex items-center gap-2 cursor-pointer text-primary hover:text-primary/80">
              <ImageIcon className="w-5 h-5" />
              <span>Upload Image</span>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageUpload}
                className="hidden"
                data-testid="edit-image-upload-input"
              />
            </label>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/admin/questions')}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving} data-testid="save-question-btn">
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
