import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { questionAPI, chapterAPI, subjectAPI, classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { Badge } from '../components/ui/badge';
import { ChevronRight, FileText } from 'lucide-react';
import { getTagColorClass, truncateText } from '../lib/utils';

export default function QuestionsPage() {
  const { classId, subjectId, chapterId } = useParams();
  const [questions, setQuestions] = useState([]);
  const [chapter, setChapter] = useState(null);
  const [subject, setSubject] = useState(null);
  const [classInfo, setClassInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [classId, subjectId, chapterId]);

  const fetchData = async () => {
    try {
      const [questionsRes, chaptersRes, subjectsRes, classesRes] = await Promise.all([
        questionAPI.getByChapter(chapterId),
        chapterAPI.getBySubject(subjectId),
        subjectAPI.getByClass(classId),
        classAPI.getAll()
      ]);
      
      setQuestions(questionsRes.data);
      const foundChapter = chaptersRes.data.find(c => c.id === chapterId);
      setChapter(foundChapter);
      const foundSubject = subjectsRes.data.find(s => s.id === subjectId);
      setSubject(foundSubject);
      const foundClass = classesRes.data.find(c => c.id === classId);
      setClassInfo(foundClass);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8 flex-wrap">
          <Link to="/" className="hover:text-foreground transition-colors" data-testid="breadcrumb-home">
            Home
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/class/${classId}`} className="hover:text-foreground transition-colors" data-testid="breadcrumb-class">
            {classInfo?.name || `Class ${classId}`}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/class/${classId}/subject/${subjectId}`} className="hover:text-foreground transition-colors" data-testid="breadcrumb-subject">
            {subject?.name || 'Subject'}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground font-medium">
            {chapter?.name || 'Chapter'}
          </span>
        </nav>

        {/* Header */}
        <div className="mb-10">
          <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-2">
            {chapter?.name || 'Chapter'}
          </h1>
          <p className="text-muted-foreground">
            {chapter?.name_hi} • {questions.length} questions
          </p>
        </div>

        {/* Questions List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-24 rounded-xl" />
            ))}
          </div>
        ) : questions.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg mb-2">No questions available yet</p>
            <p className="text-sm text-muted-foreground">
              Ask admin to add questions for this chapter
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {questions.map((question, index) => (
              <Link
                key={question.id}
                to={`/question/${question.id}`}
                className="question-card block p-5 rounded-xl border bg-card animate-slide-up"
                style={{ animationDelay: `${index * 0.05}s` }}
                data-testid={`question-card-${question.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex flex-wrap gap-2 mb-2">
                      {question.tags?.map((tag, i) => (
                        <Badge key={i} variant="secondary" className={getTagColorClass(tag)}>
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <h3 className="font-medium text-foreground mb-1">
                      {truncateText(question.question || question.question_hi, 150)}
                    </h3>
                    {question.question && question.question_hi && (
                      <p className="text-sm text-muted-foreground" lang="hi">
                        {truncateText(question.question_hi, 100)}
                      </p>
                    )}
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
