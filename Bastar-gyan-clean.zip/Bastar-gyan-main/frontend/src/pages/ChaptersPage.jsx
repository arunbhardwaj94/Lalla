import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { chapterAPI, subjectAPI, classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { ChevronRight, BookOpen, FileQuestion, ClipboardList } from 'lucide-react';

export default function ChaptersPage() {
  const { classId, subjectId } = useParams();
  const [chapters, setChapters] = useState([]);
  const [subject, setSubject] = useState(null);
  const [classInfo, setClassInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [classId, subjectId]);

  const fetchData = async () => {
    try {
      const [chaptersRes, subjectsRes, classesRes] = await Promise.all([
        chapterAPI.getBySubject(subjectId),
        subjectAPI.getByClass(classId),
        classAPI.getAll()
      ]);
      
      setChapters(chaptersRes.data);
      const foundSubject = subjectsRes.data.find(s => s.id === subjectId);
      setSubject(foundSubject);
      const foundClass = classesRes.data.find(c => c.id === classId);
      setClassInfo(foundClass);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8 flex-wrap">
          <Link to="/" className="hover:text-foreground transition-colors" data-testid="breadcrumb-home">
            Home
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/class/${classId}`} className="hover:text-foreground transition-colors" data-testid="breadcrumb-class">
            {classInfo?.name || `Class ${classId}`}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground font-medium">
            {subject?.name || 'Subject'}
          </span>
        </nav>

        {/* Header */}
        <div className="mb-10">
          <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
            {subject?.name || 'Subject'}
          </h1>
          <p className="text-muted-foreground">
            {classInfo?.name || `Class ${classId}`} • {subject?.name_hi}
          </p>
        </div>

        {/* Test Series Card */}
        <Link
          to={`/class/${classId}/subject/${subjectId}/test`}
          className="test-card flex items-center gap-4 mb-8 animate-fade-in"
          data-testid="test-series-link"
        >
          <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center">
            <ClipboardList className="w-7 h-7 text-primary" />
          </div>
          <div>
            <h3 className="font-heading text-lg font-semibold text-foreground">
              Test Series / Mock Test
            </h3>
            <p className="text-sm text-muted-foreground">
              Practice MCQs with detailed analysis
            </p>
          </div>
          <ChevronRight className="w-5 h-5 ml-auto text-primary" />
        </Link>

        {/* Chapters List */}
        <h2 className="font-heading text-xl font-semibold mb-4">Chapters</h2>
        
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        ) : chapters.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <p className="text-muted-foreground text-lg mb-2">No chapters available yet</p>
            <p className="text-sm text-muted-foreground">
              Ask admin to add chapters for this subject
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {chapters.map((chapter, index) => (
              <Link
                key={chapter.id}
                to={`/class/${classId}/subject/${subjectId}/chapter/${chapter.id}`}
                className="chapter-item animate-slide-up"
                style={{ animationDelay: `${index * 0.05}s` }}
                data-testid={`chapter-card-${chapter.id}`}
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold">
                  {chapter.order || index + 1}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-foreground">{chapter.name}</h3>
                  <p className="text-sm text-muted-foreground">{chapter.name_hi}</p>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <FileQuestion className="w-4 h-4" />
                  <ChevronRight className="w-4 h-4" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
