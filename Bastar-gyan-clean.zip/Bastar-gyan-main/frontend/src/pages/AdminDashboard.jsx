import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { statsAPI, seedAPI, classAPI, subjectAPI, chapterAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Skeleton } from '../components/ui/skeleton';
import { toast } from 'sonner';
import { 
  LayoutDashboard, FileQuestion, ClipboardList, BookOpen, 
  Layers, LogOut, Plus, Database, ChevronRight 
} from 'lucide-react';

export default function AdminDashboard() {
  const { isAuthenticated, admin, logout, loading: authLoading } = useAuth();
  const [stats, setStats] = useState(null);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated, authLoading, navigate]);

  const fetchData = async () => {
    try {
      const [statsRes, classesRes] = await Promise.all([
        statsAPI.getStats(),
        classAPI.getAll()
      ]);
      setStats(statsRes.data);
      setClasses(classesRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSeedData = async () => {
    setSeeding(true);
    try {
      const response = await seedAPI.seedDemoData();
      toast.success(`Demo data seeded! ${response.data.seeded.questions} questions added.`);
      fetchData();
    } catch (error) {
      console.error('Error seeding data:', error);
      toast.error('Failed to seed demo data');
    } finally {
      setSeeding(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <LayoutDashboard className="w-6 h-6 text-primary" />
            <h1 className="font-heading text-xl font-bold">Admin Dashboard</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              Welcome, {admin?.username}
            </span>
            <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="admin-logout-btn">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {loading ? (
            [1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-28 rounded-xl" />
            ))
          ) : (
            <>
              <div className="bg-card rounded-xl border p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <FileQuestion className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{stats?.total_questions || 0}</p>
                    <p className="text-sm text-muted-foreground">Questions</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-card rounded-xl border p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{stats?.total_mcqs || 0}</p>
                    <p className="text-sm text-muted-foreground">MCQs</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-card rounded-xl border p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{stats?.total_subjects || 0}</p>
                    <p className="text-sm text-muted-foreground">Subjects</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-card rounded-xl border p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                    <Layers className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{stats?.total_chapters || 0}</p>
                    <p className="text-sm text-muted-foreground">Chapters</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mb-10">
          <h2 className="font-heading text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="flex flex-wrap gap-4">
            <Link to="/admin/questions/add">
              <Button className="flex items-center gap-2" data-testid="add-question-btn">
                <Plus className="w-4 h-4" />
                Add Question
              </Button>
            </Link>
            <Link to="/admin/mcqs/add">
              <Button variant="secondary" className="flex items-center gap-2" data-testid="add-mcq-btn">
                <Plus className="w-4 h-4" />
                Add MCQ
              </Button>
            </Link>
            <Link to="/admin/subjects/add">
              <Button variant="outline" className="flex items-center gap-2" data-testid="add-subject-btn">
                <Plus className="w-4 h-4" />
                Add Subject
              </Button>
            </Link>
            <Link to="/admin/chapters/add">
              <Button variant="outline" className="flex items-center gap-2" data-testid="add-chapter-btn">
                <Plus className="w-4 h-4" />
                Add Chapter
              </Button>
            </Link>
            <Button 
              variant="outline" 
              onClick={handleSeedData} 
              disabled={seeding}
              className="flex items-center gap-2"
              data-testid="seed-data-btn"
            >
              <Database className="w-4 h-4" />
              {seeding ? 'Seeding...' : 'Seed Demo Data'}
            </Button>
          </div>
        </div>

        {/* Management Links */}
        <div>
          <h2 className="font-heading text-xl font-semibold mb-4">Content Management</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link 
              to="/admin/questions" 
              className="p-6 bg-card rounded-xl border hover:border-primary/30 transition-colors flex items-center justify-between"
              data-testid="manage-questions-link"
            >
              <div className="flex items-center gap-4">
                <FileQuestion className="w-8 h-8 text-primary" />
                <div>
                  <h3 className="font-medium text-foreground">Manage Questions</h3>
                  <p className="text-sm text-muted-foreground">View, edit, delete</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </Link>
            
            <Link 
              to="/admin/mcqs" 
              className="p-6 bg-card rounded-xl border hover:border-primary/30 transition-colors flex items-center justify-between"
              data-testid="manage-mcqs-link"
            >
              <div className="flex items-center gap-4">
                <ClipboardList className="w-8 h-8 text-primary" />
                <div>
                  <h3 className="font-medium text-foreground">Manage MCQs</h3>
                  <p className="text-sm text-muted-foreground">View, edit, delete</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </Link>
            
            <Link 
              to="/admin/subjects" 
              className="p-6 bg-card rounded-xl border hover:border-primary/30 transition-colors flex items-center justify-between"
              data-testid="manage-subjects-link"
            >
              <div className="flex items-center gap-4">
                <BookOpen className="w-8 h-8 text-primary" />
                <div>
                  <h3 className="font-medium text-foreground">Manage Subjects</h3>
                  <p className="text-sm text-muted-foreground">Add, remove</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </Link>
            
            <Link 
              to="/admin/chapters" 
              className="p-6 bg-card rounded-xl border hover:border-primary/30 transition-colors flex items-center justify-between"
              data-testid="manage-chapters-link"
            >
              <div className="flex items-center gap-4">
                <Layers className="w-8 h-8 text-primary" />
                <div>
                  <h3 className="font-medium text-foreground">Manage Chapters</h3>
                  <p className="text-sm text-muted-foreground">Add, remove</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
