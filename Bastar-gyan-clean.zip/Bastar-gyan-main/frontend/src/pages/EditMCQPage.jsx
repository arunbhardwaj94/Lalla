import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { classAPI, subjectAPI, chapterAPI, mcqAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Skeleton } from '../components/ui/skeleton';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';

export default function EditMCQPage() {
  const { mcqId } = useParams();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chapters, setChapters] = useState([]);
  
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedChapter, setSelectedChapter] = useState('');
  
  const [question, setQuestion] = useState('');
  const [questionHi, setQuestionHi] = useState('');
  const [options, setOptions] = useState([
    { text: '', text_hi: '' },
    { text: '', text_hi: '' },
    { text: '', text_hi: '' },
    { text: '', text_hi: '' }
  ]);
  const [correctOption, setCorrectOption] = useState('0');
  const [explanation, setExplanation] = useState('');
  const [explanationHi, setExplanationHi] = useState('');
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchMcq();
    }
  }, [isAuthenticated, authLoading, navigate, mcqId]);

  const fetchMcq = async () => {
    try {
      const [mcqRes, classesRes] = await Promise.all([
        mcqAPI.getById(mcqId),
        classAPI.getAll()
      ]);
      
      const mData = mcqRes.data;
      setClasses(classesRes.data);
      
      setSelectedClass(mData.class_id);
      setQuestion(mData.question || '');
      setQuestionHi(mData.question_hi || '');
      setOptions(mData.options || [
        { text: '', text_hi: '' },
        { text: '', text_hi: '' },
        { text: '', text_hi: '' },
        { text: '', text_hi: '' }
      ]);
      setCorrectOption(String(mData.correct_option_index || 0));
      setExplanation(mData.explanation || '');
      setExplanationHi(mData.explanation_hi || '');
      
      // Fetch subjects for the class
      const subjectsRes = await subjectAPI.getByClass(mData.class_id);
      setSubjects(subjectsRes.data);
      setSelectedSubject(mData.subject_id);
      
      // Fetch chapters for the subject
      const chaptersRes = await chapterAPI.getBySubject(mData.subject_id);
      setChapters(chaptersRes.data);
      setSelectedChapter(mData.chapter_id);
      
    } catch (error) {
      console.error('Error fetching MCQ:', error);
      toast.error('Failed to load MCQ');
      navigate('/admin/mcqs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedClass && !loading) {
      fetchSubjects(selectedClass);
    }
  }, [selectedClass]);

  useEffect(() => {
    if (selectedSubject && !loading) {
      fetchChapters(selectedSubject);
    }
  }, [selectedSubject]);

  const fetchSubjects = async (classId) => {
    try {
      const response = await subjectAPI.getByClass(classId);
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchChapters = async (subjectId) => {
    try {
      const response = await chapterAPI.getBySubject(subjectId);
      setChapters(response.data);
    } catch (error) {
      console.error('Error fetching chapters:', error);
    }
  };

  const updateOption = (index, field, value) => {
    const newOptions = [...options];
    newOptions[index][field] = value;
    setOptions(newOptions);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!selectedClass || !selectedSubject || !selectedChapter) {
      toast.error('Please select class, subject, and chapter');
      return;
    }
    
    if (!question.trim() && !questionHi.trim()) {
      toast.error('Please enter the question');
      return;
    }
    
    const validOptions = options.filter(opt => opt.text.trim() || opt.text_hi.trim());
    if (validOptions.length < 2) {
      toast.error('Please add at least 2 options');
      return;
    }

    setSaving(true);
    
    try {
      await mcqAPI.update(mcqId, {
        question: question.trim(),
        question_hi: questionHi.trim(),
        options: options.filter(opt => opt.text.trim() || opt.text_hi.trim()),
        correct_option_index: parseInt(correctOption),
        class_id: selectedClass,
        subject_id: selectedSubject,
        chapter_id: selectedChapter,
        explanation: explanation.trim(),
        explanation_hi: explanationHi.trim()
      });
      
      toast.success('MCQ updated successfully!');
      navigate('/admin/mcqs');
    } catch (error) {
      console.error('Error updating MCQ:', error);
      toast.error('Failed to update MCQ');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Skeleton className="h-8 w-64 mb-8" />
          <Skeleton className="h-96 rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin/mcqs')} data-testid="back-btn">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Edit MCQ</h1>
            <p className="text-muted-foreground">Update MCQ details</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Selection */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Location</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Class</Label>
                <Select value={selectedClass} onValueChange={(val) => { setSelectedClass(val); setSelectedSubject(''); setSelectedChapter(''); }}>
                  <SelectTrigger data-testid="edit-mcq-class-select">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Subject</Label>
                <Select value={selectedSubject} onValueChange={(val) => { setSelectedSubject(val); setSelectedChapter(''); }} disabled={!selectedClass}>
                  <SelectTrigger data-testid="edit-mcq-subject-select">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subj) => (
                      <SelectItem key={subj.id} value={subj.id}>{subj.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Chapter</Label>
                <Select value={selectedChapter} onValueChange={setSelectedChapter} disabled={!selectedSubject}>
                  <SelectTrigger data-testid="edit-mcq-chapter-select">
                    <SelectValue placeholder="Select chapter" />
                  </SelectTrigger>
                  <SelectContent>
                    {chapters.map((chap) => (
                      <SelectItem key={chap.id} value={chap.id}>{chap.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Question */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Question</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="mcqQuestion">Question (English)</Label>
                <Textarea
                  id="mcqQuestion"
                  placeholder="Enter question in English..."
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  rows={3}
                  data-testid="edit-mcq-question-en-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mcqQuestionHi">Question (Hindi)</Label>
                <Textarea
                  id="mcqQuestionHi"
                  placeholder="प्रश्न हिंदी में लिखें..."
                  value={questionHi}
                  onChange={(e) => setQuestionHi(e.target.value)}
                  rows={3}
                  data-testid="edit-mcq-question-hi-input"
                />
              </div>
            </div>
          </div>

          {/* Options */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Options</h2>
            <RadioGroup value={correctOption} onValueChange={setCorrectOption}>
              <div className="space-y-4">
                {options.map((option, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 rounded-lg border bg-muted/30">
                    <RadioGroupItem value={String(index)} id={`option-${index}`} className="mt-3" />
                    <div className="flex-1 space-y-3">
                      <Label htmlFor={`option-${index}`} className="text-sm font-medium">
                        Option {String.fromCharCode(65 + index)} {correctOption === String(index) && '(Correct)'}
                      </Label>
                      <Input
                        placeholder={`Option ${String.fromCharCode(65 + index)} in English...`}
                        value={option.text}
                        onChange={(e) => updateOption(index, 'text', e.target.value)}
                        data-testid={`edit-mcq-option-${index}-en`}
                      />
                      <Input
                        placeholder={`विकल्प ${String.fromCharCode(65 + index)} हिंदी में...`}
                        value={option.text_hi}
                        onChange={(e) => updateOption(index, 'text_hi', e.target.value)}
                        data-testid={`edit-mcq-option-${index}-hi`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </RadioGroup>
            <p className="text-sm text-muted-foreground mt-4">
              Select the radio button next to the correct answer
            </p>
          </div>

          {/* Explanation */}
          <div className="bg-card rounded-xl border p-6">
            <h2 className="font-medium text-foreground mb-4">Explanation (Optional)</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="explanation">Explanation (English)</Label>
                <Textarea
                  id="explanation"
                  placeholder="Explanation in English..."
                  value={explanation}
                  onChange={(e) => setExplanation(e.target.value)}
                  rows={3}
                  data-testid="edit-mcq-explanation-en-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="explanationHi">Explanation (Hindi)</Label>
                <Textarea
                  id="explanationHi"
                  placeholder="व्याख्या हिंदी में..."
                  value={explanationHi}
                  onChange={(e) => setExplanationHi(e.target.value)}
                  rows={3}
                  data-testid="edit-mcq-explanation-hi-input"
                />
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/admin/mcqs')}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving} data-testid="save-mcq-btn">
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
