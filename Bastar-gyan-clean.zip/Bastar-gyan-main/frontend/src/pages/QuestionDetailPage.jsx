import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { questionAPI, chapterAPI, subjectAPI, classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { ChevronRight, Download, Share2, ArrowLeft } from 'lucide-react';
import { getTagColorClass, getWhatsAppShareUrl, generatePDF } from '../lib/utils';

export default function QuestionDetailPage() {
  const { questionId } = useParams();
  const [question, setQuestion] = useState(null);
  const [chapter, setChapter] = useState(null);
  const [subject, setSubject] = useState(null);
  const [classInfo, setClassInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [questionId]);

  const fetchData = async () => {
    try {
      const questionRes = await questionAPI.getById(questionId);
      const questionData = questionRes.data;
      setQuestion(questionData);

      // Fetch related data
      const [chaptersRes, subjectsRes, classesRes] = await Promise.all([
        chapterAPI.getBySubject(questionData.subject_id),
        subjectAPI.getByClass(questionData.class_id),
        classAPI.getAll()
      ]);

      const foundChapter = chaptersRes.data.find(c => c.id === questionData.chapter_id);
      setChapter(foundChapter);
      const foundSubject = subjectsRes.data.find(s => s.id === questionData.subject_id);
      setSubject(foundSubject);
      const foundClass = classesRes.data.find(c => c.id === questionData.class_id);
      setClassInfo(foundClass);
    } catch (error) {
      console.error('Error fetching question:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    const text = `📚 ${question.question || question.question_hi}\n\nBastar Gyan - For SAGES Students`;
    const url = window.location.href;
    window.open(getWhatsAppShareUrl(text, url), '_blank');
  };

  const handleDownloadPDF = () => {
    generatePDF(
      question.question || question.question_hi,
      question.answer || question.answer_hi
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Skeleton className="h-8 w-64 mb-8" />
          <Skeleton className="h-12 w-full mb-4" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!question) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground">Question not found</p>
          <Link to="/" className="text-primary hover:underline mt-4 inline-block">
            Go back home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8 flex-wrap no-print">
          <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/class/${question.class_id}`} className="hover:text-foreground transition-colors">
            {classInfo?.name || `Class ${question.class_id}`}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/class/${question.class_id}/subject/${question.subject_id}`} className="hover:text-foreground transition-colors">
            {subject?.name || 'Subject'}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/class/${question.class_id}/subject/${question.subject_id}/chapter/${question.chapter_id}`} className="hover:text-foreground transition-colors">
            {chapter?.name || 'Chapter'}
          </Link>
        </nav>

        {/* Back Button */}
        <Link 
          to={`/class/${question.class_id}/subject/${question.subject_id}/chapter/${question.chapter_id}`}
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6 no-print"
          data-testid="back-btn"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to questions
        </Link>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {question.tags?.map((tag, i) => (
            <Badge key={i} variant="secondary" className={getTagColorClass(tag)}>
              {tag}
            </Badge>
          ))}
        </div>

        {/* Question - English First */}
        <div className="bg-card rounded-2xl border p-6 md:p-8 mb-6 animate-fade-in">
          <h2 className="text-sm font-medium text-primary mb-3">Question</h2>
          {question.question && (
            <p className="font-heading text-xl md:text-2xl text-foreground mb-3 leading-relaxed">
              {question.question}
            </p>
          )}
          {question.question_hi && (
            <p className="text-muted-foreground" lang="hi">
              {question.question_hi}
            </p>
          )}
        </div>

        {/* Answer - English First */}
        <div className="bg-card rounded-2xl border p-6 md:p-8 mb-6 animate-slide-up">
          <h2 className="text-sm font-medium text-primary mb-3">Answer</h2>
          {question.answer && (
            <div className="prose prose-lg max-w-none mb-4">
              <p className="text-foreground leading-relaxed whitespace-pre-wrap">
                {question.answer}
              </p>
            </div>
          )}
          {question.answer_hi && (
            <div className="prose max-w-none text-muted-foreground">
              <p className="leading-relaxed whitespace-pre-wrap" lang="hi">
                {question.answer_hi}
              </p>
            </div>
          )}

          {/* Images */}
          {question.images && question.images.length > 0 && (
            <div className="mt-6 space-y-4">
              <h3 className="text-sm font-medium text-muted-foreground">Diagrams / Images:</h3>
              {question.images.map((img, i) => (
                <img
                  key={i}
                  src={img}
                  alt={`Diagram ${i + 1}`}
                  className="answer-image max-w-full rounded-lg border"
                />
              ))}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4 no-print">
          <Button
            onClick={handleDownloadPDF}
            className="pdf-download flex items-center gap-2"
            data-testid="download-pdf-btn"
          >
            <Download className="w-4 h-4" />
            Download PDF
          </Button>
          
          <Button
            onClick={handleShare}
            className="whatsapp-share flex items-center gap-2"
            data-testid="share-whatsapp-btn"
          >
            <Share2 className="w-4 h-4" />
            Share on WhatsApp
          </Button>
        </div>
      </div>
    </div>
  );
}
