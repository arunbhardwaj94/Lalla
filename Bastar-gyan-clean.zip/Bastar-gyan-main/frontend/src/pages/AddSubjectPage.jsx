import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { classAPI, subjectAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';

export default function AddSubjectPage() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [name, setName] = useState('');
  const [nameHi, setNameHi] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchClasses();
    }
  }, [isAuthenticated, authLoading, navigate]);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!selectedClass) {
      toast.error('Please select a class');
      return;
    }
    
    if (!name.trim() || !nameHi.trim()) {
      toast.error('Please enter subject name in both languages');
      return;
    }

    setLoading(true);
    
    try {
      await subjectAPI.create({
        name: name.trim(),
        name_hi: nameHi.trim(),
        class_id: selectedClass,
        image_url: imageUrl.trim() || null
      });
      
      toast.success('Subject added successfully!');
      navigate('/admin/dashboard');
    } catch (error) {
      console.error('Error creating subject:', error);
      toast.error('Failed to add subject');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin/dashboard')} data-testid="back-btn">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Add Subject</h1>
            <p className="text-muted-foreground">Add a new subject to a class</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-card rounded-xl border p-6 space-y-4">
            <div className="space-y-2">
              <Label>Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger data-testid="subject-class-select">
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>{cls.name_hi}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="nameHi">Subject Name (Hindi)</Label>
              <Input
                id="nameHi"
                placeholder="विषय का नाम हिंदी में..."
                value={nameHi}
                onChange={(e) => setNameHi(e.target.value)}
                data-testid="subject-name-hi-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="name">Subject Name (English)</Label>
              <Input
                id="name"
                placeholder="Subject name in English..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                data-testid="subject-name-en-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="imageUrl">Image URL (Optional)</Label>
              <Input
                id="imageUrl"
                placeholder="https://..."
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                data-testid="subject-image-url-input"
              />
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/admin/dashboard')}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading} data-testid="submit-subject-btn">
              {loading ? 'Adding...' : 'Add Subject'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
