import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { questionAPI, classAPI, subjectAPI, chapterAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Skeleton } from '../components/ui/skeleton';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Edit, Trash2, FileQuestion, Search } from 'lucide-react';
import { Input } from '../components/ui/input';
import { getTagColorClass, truncateText } from '../lib/utils';

export default function ManageQuestionsPage() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [questions, setQuestions] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chapters, setChapters] = useState([]);
  
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedChapter, setSelectedChapter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchClasses();
    }
  }, [isAuthenticated, authLoading, navigate]);

  useEffect(() => {
    if (selectedClass) {
      fetchSubjects(selectedClass);
      setSelectedSubject('');
      setSelectedChapter('');
      setChapters([]);
      setQuestions([]);
    }
  }, [selectedClass]);

  useEffect(() => {
    if (selectedSubject) {
      fetchChapters(selectedSubject);
      setSelectedChapter('');
      setQuestions([]);
    }
  }, [selectedSubject]);

  useEffect(() => {
    if (selectedChapter) {
      fetchQuestions(selectedChapter);
    }
  }, [selectedChapter]);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubjects = async (classId) => {
    try {
      const response = await subjectAPI.getByClass(classId);
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchChapters = async (subjectId) => {
    try {
      const response = await chapterAPI.getBySubject(subjectId);
      setChapters(response.data);
    } catch (error) {
      console.error('Error fetching chapters:', error);
    }
  };

  const fetchQuestions = async (chapterId) => {
    setLoading(true);
    try {
      const response = await questionAPI.getByChapter(chapterId);
      setQuestions(response.data);
    } catch (error) {
      console.error('Error fetching questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (questionId) => {
    if (!window.confirm('Are you sure you want to delete this question?')) return;
    
    setDeleting(questionId);
    try {
      await questionAPI.delete(questionId);
      toast.success('Question deleted successfully');
      setQuestions(questions.filter(q => q.id !== questionId));
    } catch (error) {
      console.error('Error deleting question:', error);
      toast.error('Failed to delete question');
    } finally {
      setDeleting(null);
    }
  };

  const filteredQuestions = questions.filter(q => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      q.question?.toLowerCase().includes(query) ||
      q.question_hi?.toLowerCase().includes(query)
    );
  });

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/dashboard')} data-testid="back-btn">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-heading text-2xl font-bold text-foreground">Manage Questions</h1>
              <p className="text-muted-foreground">View, edit, and delete questions</p>
            </div>
          </div>
          <Link to="/admin/questions/add">
            <Button className="flex items-center gap-2" data-testid="add-new-question-btn">
              <Plus className="w-4 h-4" />
              Add New Question
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="bg-card rounded-xl border p-6 mb-6">
          <h2 className="font-medium text-foreground mb-4">Filter Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger data-testid="filter-class-select">
                <SelectValue placeholder="Select Class" />
              </SelectTrigger>
              <SelectContent>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedSubject} onValueChange={setSelectedSubject} disabled={!selectedClass}>
              <SelectTrigger data-testid="filter-subject-select">
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subj) => (
                  <SelectItem key={subj.id} value={subj.id}>{subj.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedChapter} onValueChange={setSelectedChapter} disabled={!selectedSubject}>
              <SelectTrigger data-testid="filter-chapter-select">
                <SelectValue placeholder="Select Chapter" />
              </SelectTrigger>
              <SelectContent>
                {chapters.map((chap) => (
                  <SelectItem key={chap.id} value={chap.id}>{chap.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search questions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-questions-input"
              />
            </div>
          </div>
        </div>

        {/* Questions List */}
        {!selectedChapter ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <FileQuestion className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Select a class, subject, and chapter to view questions</p>
          </div>
        ) : loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 rounded-xl" />
            ))}
          </div>
        ) : filteredQuestions.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <FileQuestion className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No questions found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredQuestions.map((question) => (
              <div
                key={question.id}
                className="bg-card rounded-xl border p-5 hover:border-primary/30 transition-colors"
                data-testid={`question-item-${question.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex flex-wrap gap-2 mb-2">
                      {question.tags?.map((tag, i) => (
                        <Badge key={i} variant="secondary" className={getTagColorClass(tag)}>
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <h3 className="font-medium text-foreground mb-1">
                      {truncateText(question.question || question.question_hi, 150)}
                    </h3>
                    {question.question_hi && question.question && (
                      <p className="text-sm text-muted-foreground" lang="hi">
                        {truncateText(question.question_hi, 100)}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Link to={`/admin/questions/edit/${question.id}`}>
                      <Button variant="outline" size="sm" className="flex items-center gap-1" data-testid={`edit-question-${question.id}`}>
                        <Edit className="w-4 h-4" />
                        Edit
                      </Button>
                    </Link>
                    <Button 
                      variant="destructive" 
                      size="sm" 
                      className="flex items-center gap-1"
                      onClick={() => handleDelete(question.id)}
                      disabled={deleting === question.id}
                      data-testid={`delete-question-${question.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                      {deleting === question.id ? 'Deleting...' : 'Delete'}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
