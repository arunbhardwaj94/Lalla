import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { classAPI, subjectAPI, chapterAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Skeleton } from '../components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Edit, Trash2, Layers } from 'lucide-react';

export default function ManageChaptersPage() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [chapters, setChapters] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchClasses();
    }
  }, [isAuthenticated, authLoading, navigate]);

  useEffect(() => {
    if (selectedClass) {
      fetchSubjects(selectedClass);
      setSelectedSubject('');
      setChapters([]);
    }
  }, [selectedClass]);

  useEffect(() => {
    if (selectedSubject) {
      fetchChapters(selectedSubject);
    }
  }, [selectedSubject]);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubjects = async (classId) => {
    try {
      const response = await subjectAPI.getByClass(classId);
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchChapters = async (subjectId) => {
    setLoading(true);
    try {
      const response = await chapterAPI.getBySubject(subjectId);
      setChapters(response.data);
    } catch (error) {
      console.error('Error fetching chapters:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (chapterId) => {
    if (!window.confirm('Are you sure you want to delete this chapter? All questions and MCQs in this chapter will also be deleted.')) return;
    
    setDeleting(chapterId);
    try {
      await chapterAPI.delete(chapterId);
      toast.success('Chapter deleted successfully');
      setChapters(chapters.filter(c => c.id !== chapterId));
    } catch (error) {
      console.error('Error deleting chapter:', error);
      toast.error('Failed to delete chapter');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/dashboard')} data-testid="back-btn">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-heading text-2xl font-bold text-foreground">Manage Chapters</h1>
              <p className="text-muted-foreground">View and delete chapters</p>
            </div>
          </div>
          <Link to="/admin/chapters/add">
            <Button className="flex items-center gap-2" data-testid="add-new-chapter-btn">
              <Plus className="w-4 h-4" />
              Add New Chapter
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="bg-card rounded-xl border p-6 mb-6">
          <h2 className="font-medium text-foreground mb-4">Filter Chapters</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger data-testid="filter-chapter-class-select">
                <SelectValue placeholder="Select Class" />
              </SelectTrigger>
              <SelectContent>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedSubject} onValueChange={setSelectedSubject} disabled={!selectedClass}>
              <SelectTrigger data-testid="filter-chapter-subject-select">
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subj) => (
                  <SelectItem key={subj.id} value={subj.id}>{subj.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Chapters List */}
        {!selectedSubject ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <Layers className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Select a class and subject to view chapters</p>
          </div>
        ) : loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        ) : chapters.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <Layers className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No chapters found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {chapters.map((chapter) => (
              <div
                key={chapter.id}
                className="bg-card rounded-xl border p-4 hover:border-primary/30 transition-colors flex items-center justify-between"
                data-testid={`chapter-item-${chapter.id}`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {chapter.order || '?'}
                  </div>
                  <div>
                    <h3 className="font-medium text-foreground">{chapter.name}</h3>
                    <p className="text-sm text-muted-foreground">{chapter.name_hi}</p>
                  </div>
                </div>
                
                <Button 
                  variant="destructive" 
                  size="sm" 
                  className="flex items-center gap-1"
                  onClick={() => handleDelete(chapter.id)}
                  disabled={deleting === chapter.id}
                  data-testid={`delete-chapter-${chapter.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                  {deleting === chapter.id ? 'Deleting...' : 'Delete'}
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
