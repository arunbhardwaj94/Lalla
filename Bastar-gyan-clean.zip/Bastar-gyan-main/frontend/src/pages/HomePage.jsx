import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { BookOpen, GraduationCap, Award, ChevronRight } from 'lucide-react';


const classConfig = {
  '10': { 
    icon: BookOpen, 
    gradient: 'from-blue-500 to-blue-600',
    lightBg: 'bg-blue-50 dark:bg-blue-950/30',
    iconBg: 'bg-blue-100 dark:bg-blue-900/50'
  },
  '11': { 
    icon: GraduationCap, 
    gradient: 'from-emerald-500 to-emerald-600',
    lightBg: 'bg-emerald-50 dark:bg-emerald-950/30',
    iconBg: 'bg-emerald-100 dark:bg-emerald-900/50'
  },
  '12': { 
    icon: Award, 
    gradient: 'from-purple-500 to-purple-600',
    lightBg: 'bg-purple-50 dark:bg-purple-950/30',
    iconBg: 'bg-purple-100 dark:bg-purple-900/50'
  },
};

export default function HomePage() {
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Compact Hero Section */}
      <section className="py-6 md:py-8 bg-gradient-to-b from-primary/5 to-transparent">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center text-center">
            <img 
              src={LOGO_URL} 
              alt="Bastar Gyan Logo" 
              className="h-20 md:h-24 w-auto mb-3 object-contain"
            />
            <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-1">
              Bastar <span className="text-primary">Gyan</span>
            </h1>
            <p className="text-sm md:text-base text-muted-foreground">
              Important Questions & Answers for Board Exams
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              SAGES (Swami Atmanand Government Excellent Schools)
            </p>
          </div>
        </div>
      </section>

      {/* Class Selection - Main Focus */}
      <section className="py-6 md:py-10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-6">
            <h2 className="font-heading text-xl md:text-2xl font-semibold text-foreground mb-1">
              Select Your Class
            </h2>
            <p className="text-sm text-muted-foreground">Choose your class to start learning</p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-36 rounded-2xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {classes.map((cls, index) => {
                const config = classConfig[cls.id] || classConfig['10'];
                const IconComponent = config.icon;
                
                return (
                  <Link
                    key={cls.id}
                    to={`/class/${cls.id}`}
                    className={`group relative overflow-hidden rounded-2xl ${config.lightBg} border border-border/50 p-6 transition-all duration-300 hover:shadow-xl hover:scale-[1.02] hover:border-primary/30 animate-fade-in`}
                    style={{ animationDelay: `${index * 0.1}s` }}
                    data-testid={`class-card-${cls.id}`}
                  >
                    {/* Gradient accent */}
                    <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${config.gradient}`} />
                    
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 rounded-xl ${config.iconBg} flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform`}>
                        <IconComponent className="w-7 h-7 text-primary" />
                      </div>
                      
                      <div className="flex-1">
                        <h3 className="font-heading text-xl font-bold text-foreground mb-0.5">
                          {cls.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">{cls.name_hi}</p>
                      </div>
                      
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Features - Compact */}
      <section className="py-8 md:py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="flex items-start gap-4 p-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center flex-shrink-0">
                <span className="text-xl">🎯</span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Important Questions</h3>
                <p className="text-sm text-muted-foreground">Tagged as IMP 2023, Repeated for easy identification</p>
              </div>
            </div>
            
            <div className="flex items-start gap-4 p-4">
              <div className="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center flex-shrink-0">
                <span className="text-xl">📝</span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Test Series</h3>
                <p className="text-sm text-muted-foreground">Practice MCQs with detailed analysis</p>
              </div>
            </div>
            
            <div className="flex items-start gap-4 p-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                <span className="text-xl">📱</span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Offline Ready</h3>
                <p className="text-sm text-muted-foreground">Download PDFs and study offline</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
