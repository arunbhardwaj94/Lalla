import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mcqAPI, chapterAPI, subjectAPI, classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { ChevronRight, ArrowLeft, CheckCircle2, XCircle, RotateCcw, Trophy, TrendingUp, AlertTriangle } from 'lucide-react';
import { cn } from '../lib/utils';

export default function QuizPage() {
  const { classId, subjectId } = useParams();
  const [chapters, setChapters] = useState([]);
  const [selectedChapter, setSelectedChapter] = useState(null);
  const [mcqs, setMcqs] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResult, setShowResult] = useState(false);
  const [subject, setSubject] = useState(null);
  const [classInfo, setClassInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quizStarted, setQuizStarted] = useState(false);

  useEffect(() => {
    fetchInitialData();
  }, [classId, subjectId]);

  const fetchInitialData = async () => {
    try {
      const [chaptersRes, subjectsRes, classesRes] = await Promise.all([
        chapterAPI.getBySubject(subjectId),
        subjectAPI.getByClass(classId),
        classAPI.getAll()
      ]);
      
      setChapters(chaptersRes.data);
      const foundSubject = subjectsRes.data.find(s => s.id === subjectId);
      setSubject(foundSubject);
      const foundClass = classesRes.data.find(c => c.id === classId);
      setClassInfo(foundClass);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const startQuiz = async (chapterId) => {
    setLoading(true);
    try {
      const mcqsRes = await mcqAPI.getByChapter(chapterId);
      setMcqs(mcqsRes.data);
      setSelectedChapter(chapters.find(c => c.id === chapterId));
      setQuizStarted(true);
      setCurrentIndex(0);
      setAnswers({});
      setShowResult(false);
    } catch (error) {
      console.error('Error fetching MCQs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (optionIndex) => {
    if (answers[currentIndex] !== undefined) return;
    setAnswers({ ...answers, [currentIndex]: optionIndex });
  };

  const nextQuestion = () => {
    if (currentIndex < mcqs.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setShowResult(true);
    }
  };

  const prevQuestion = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const resetQuiz = () => {
    setQuizStarted(false);
    setSelectedChapter(null);
    setMcqs([]);
    setCurrentIndex(0);
    setAnswers({});
    setShowResult(false);
  };

  const getScore = () => {
    let correct = 0;
    mcqs.forEach((mcq, index) => {
      if (answers[index] === mcq.correct_option_index) {
        correct++;
      }
    });
    return correct;
  };

  // Generate detailed analysis
  const getAnalysis = () => {
    const totalQuestions = mcqs.length;
    const correctAnswers = getScore();
    const incorrectAnswers = totalQuestions - correctAnswers;
    const percentage = Math.round((correctAnswers / totalQuestions) * 100);
    
    // Analyze which topics need improvement
    const incorrectQuestions = [];
    mcqs.forEach((mcq, index) => {
      if (answers[index] !== mcq.correct_option_index) {
        incorrectQuestions.push({
          question: mcq.question,
          question_hi: mcq.question_hi,
          yourAnswer: mcq.options[answers[index]]?.text || 'Not answered',
          correctAnswer: mcq.options[mcq.correct_option_index]?.text || 'N/A',
          explanation: mcq.explanation || mcq.explanation_hi
        });
      }
    });
    
    let performanceLevel = '';
    let performanceColor = '';
    let recommendations = [];
    
    if (percentage >= 80) {
      performanceLevel = 'Excellent';
      performanceColor = 'text-green-500';
      recommendations = [
        'Great job! You have a strong understanding of this chapter.',
        'Consider helping your peers with this topic.',
        'Try solving previous year board questions for this chapter.'
      ];
    } else if (percentage >= 60) {
      performanceLevel = 'Good';
      performanceColor = 'text-blue-500';
      recommendations = [
        'You have a decent understanding but need some improvement.',
        'Focus on reviewing the concepts you got wrong.',
        'Practice more questions from similar topics.'
      ];
    } else if (percentage >= 40) {
      performanceLevel = 'Average';
      performanceColor = 'text-amber-500';
      recommendations = [
        'You need to revise this chapter more thoroughly.',
        'Go back to the basics and understand core concepts.',
        'Make notes of important formulas and definitions.'
      ];
    } else {
      performanceLevel = 'Needs Improvement';
      performanceColor = 'text-red-500';
      recommendations = [
        'This chapter needs significant attention.',
        'Start from the beginning and understand each concept step by step.',
        'Consider seeking help from your teacher or peers.',
        'Watch video explanations for better understanding.'
      ];
    }
    
    return {
      totalQuestions,
      correctAnswers,
      incorrectAnswers,
      percentage,
      incorrectQuestions,
      performanceLevel,
      performanceColor,
      recommendations
    };
  };

  if (loading) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Skeleton className="h-8 w-64 mb-8" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Chapter Selection View
  if (!quizStarted) {
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8 flex-wrap">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <ChevronRight className="w-4 h-4" />
            <Link to="/test-series" className="hover:text-foreground transition-colors">Test Series</Link>
            <ChevronRight className="w-4 h-4" />
            <span className="text-foreground font-medium">{subject?.name || 'Subject'}</span>
          </nav>

          {/* Header */}
          <div className="mb-10">
            <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-2">
              {subject?.name || 'Subject'} - Test Series
            </h1>
            <p className="text-muted-foreground">
              Select a chapter to start the quiz
            </p>
          </div>

          {/* Chapter Selection */}
          {chapters.length === 0 ? (
            <div className="text-center py-16 bg-muted/30 rounded-2xl">
              <p className="text-muted-foreground">No chapters available for quiz</p>
            </div>
          ) : (
            <div className="space-y-3">
              {chapters.map((chapter, index) => (
                <button
                  key={chapter.id}
                  onClick={() => startQuiz(chapter.id)}
                  className="chapter-item w-full text-left animate-slide-up"
                  style={{ animationDelay: `${index * 0.05}s` }}
                  data-testid={`quiz-chapter-${chapter.id}`}
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {chapter.order || index + 1}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground">{chapter.name}</h3>
                    <p className="text-sm text-muted-foreground">{chapter.name_hi}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-primary" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Results View with Detailed Analysis
  if (showResult) {
    const analysis = getAnalysis();
    
    return (
      <div className="min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-3xl">
          {/* Score Summary */}
          <div className="bg-card rounded-2xl border p-8 text-center animate-fade-in mb-6">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <Trophy className={cn(
                "w-10 h-10",
                analysis.percentage >= 70 ? "text-amber-500" : "text-primary"
              )} />
            </div>
            
            <h1 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-2">
              Quiz Complete!
            </h1>
            <p className="text-muted-foreground mb-6">
              {selectedChapter?.name}
            </p>
            
            <div className="bg-muted/50 rounded-xl p-6 mb-6">
              <div className="text-5xl font-bold text-primary mb-2">
                {analysis.correctAnswers}/{analysis.totalQuestions}
              </div>
              <div className="text-muted-foreground mb-2">
                {analysis.percentage}% Correct
              </div>
              <div className={cn("font-semibold text-lg", analysis.performanceColor)}>
                {analysis.performanceLevel}
              </div>
            </div>
          </div>

          {/* Detailed Analysis */}
          <div className="bg-card rounded-2xl border p-6 mb-6 animate-slide-up">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-6 h-6 text-primary" />
              <h2 className="font-heading text-xl font-semibold">Detailed Analysis</h2>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-xl">
                <div className="text-2xl font-bold text-green-600">{analysis.correctAnswers}</div>
                <div className="text-sm text-muted-foreground">Correct</div>
              </div>
              <div className="text-center p-4 bg-red-50 dark:bg-red-900/20 rounded-xl">
                <div className="text-2xl font-bold text-red-600">{analysis.incorrectAnswers}</div>
                <div className="text-sm text-muted-foreground">Incorrect</div>
              </div>
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                <div className="text-2xl font-bold text-blue-600">{analysis.percentage}%</div>
                <div className="text-sm text-muted-foreground">Score</div>
              </div>
            </div>

            {/* Recommendations */}
            <div className="mb-6">
              <h3 className="font-medium text-foreground mb-3">Recommendations:</h3>
              <ul className="space-y-2">
                {analysis.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-primary mt-1">•</span>
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Topics to Improve */}
          {analysis.incorrectQuestions.length > 0 && (
            <div className="bg-card rounded-2xl border p-6 mb-6 animate-slide-up">
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle className="w-6 h-6 text-amber-500" />
                <h2 className="font-heading text-xl font-semibold">Topics to Improve</h2>
              </div>
              
              <div className="space-y-4">
                {analysis.incorrectQuestions.map((item, i) => (
                  <div key={i} className="p-4 bg-red-50 dark:bg-red-900/10 rounded-xl border border-red-200 dark:border-red-900/30">
                    <p className="font-medium text-foreground mb-2">{item.question}</p>
                    {item.question_hi && (
                      <p className="text-sm text-muted-foreground mb-2" lang="hi">{item.question_hi}</p>
                    )}
                    <div className="text-sm space-y-1">
                      <p><span className="text-red-600">Your Answer:</span> {item.yourAnswer}</p>
                      <p><span className="text-green-600">Correct Answer:</span> {item.correctAnswer}</p>
                      {item.explanation && (
                        <p className="text-muted-foreground mt-2 italic">{item.explanation}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-wrap justify-center gap-4">
            <Button onClick={resetQuiz} variant="outline" className="flex items-center gap-2" data-testid="back-to-chapters-btn">
              <ArrowLeft className="w-4 h-4" />
              Back to Chapters
            </Button>
            <Button onClick={() => startQuiz(selectedChapter.id)} className="flex items-center gap-2" data-testid="retry-quiz-btn">
              <RotateCcw className="w-4 h-4" />
              Retry Quiz
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Quiz View
  const currentMcq = mcqs[currentIndex];
  const userAnswer = answers[currentIndex];
  const isAnswered = userAnswer !== undefined;

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-3xl">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span>Question {currentIndex + 1} of {mcqs.length}</span>
            <span>{Object.keys(answers).length} answered</span>
          </div>
          <Progress value={((currentIndex + 1) / mcqs.length) * 100} className="h-2" />
        </div>

        {/* Question Card */}
        <div className="bg-card rounded-2xl border p-6 md:p-8 mb-6 animate-fade-in">
          {currentMcq?.question && (
            <p className="font-heading text-xl md:text-2xl text-foreground mb-3 leading-relaxed">
              {currentMcq.question}
            </p>
          )}
          {currentMcq?.question_hi && (
            <p className="text-muted-foreground" lang="hi">
              {currentMcq.question_hi}
            </p>
          )}
        </div>

        {/* Options */}
        <div className="space-y-3 mb-8">
          {currentMcq?.options?.map((option, index) => {
            const isCorrect = index === currentMcq.correct_option_index;
            const isSelected = userAnswer === index;
            
            return (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                disabled={isAnswered}
                className={cn(
                  "quiz-option w-full p-4 rounded-xl border text-left transition-all",
                  isAnswered && isCorrect && "correct",
                  isAnswered && isSelected && !isCorrect && "incorrect",
                  isSelected && !isAnswered && "selected",
                  !isAnswered && "hover:scale-[1.01]"
                )}
                data-testid={`quiz-option-${index}`}
              >
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium",
                    isAnswered && isCorrect ? "bg-green-500 text-white" :
                    isAnswered && isSelected && !isCorrect ? "bg-red-500 text-white" :
                    "bg-muted text-muted-foreground"
                  )}>
                    {isAnswered && isCorrect ? <CheckCircle2 className="w-5 h-5" /> :
                     isAnswered && isSelected && !isCorrect ? <XCircle className="w-5 h-5" /> :
                     String.fromCharCode(65 + index)}
                  </div>
                  <div className="flex-1">
                    {option.text && (
                      <p className="font-medium text-foreground">{option.text}</p>
                    )}
                    {option.text_hi && (
                      <p className="text-sm text-muted-foreground" lang="hi">{option.text_hi}</p>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Explanation */}
        {isAnswered && (currentMcq?.explanation || currentMcq?.explanation_hi) && (
          <div className="bg-primary/5 rounded-xl p-4 mb-6 animate-fade-in">
            <h4 className="font-medium text-primary mb-2">Explanation:</h4>
            {currentMcq.explanation && (
              <p className="text-foreground mb-1">{currentMcq.explanation}</p>
            )}
            {currentMcq.explanation_hi && (
              <p className="text-muted-foreground" lang="hi">{currentMcq.explanation_hi}</p>
            )}
          </div>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button
            onClick={prevQuestion}
            variant="outline"
            disabled={currentIndex === 0}
            data-testid="prev-question-btn"
          >
            Previous
          </Button>
          
          <Button
            onClick={nextQuestion}
            disabled={!isAnswered}
            data-testid="next-question-btn"
          >
            {currentIndex === mcqs.length - 1 ? 'Finish Quiz' : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
}
