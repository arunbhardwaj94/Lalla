import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { subjectAPI, classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { ChevronRight, Atom, FlaskConical, Calculator, Leaf, BookText, Globe, Beaker } from 'lucide-react';

const subjectIconMap = {
  'physics': Atom,
  'chemistry': FlaskConical,
  'mathematics': Calculator,
  'maths': Calculator,
  'biology': Leaf,
  'science': Beaker,
  'hindi': BookText,
  'english': Globe,
};

const subjectColorMap = {
  'physics': 'from-blue-500/20 to-blue-600/5 border-blue-200 dark:border-blue-800',
  'chemistry': 'from-orange-500/20 to-orange-600/5 border-orange-200 dark:border-orange-800',
  'mathematics': 'from-purple-500/20 to-purple-600/5 border-purple-200 dark:border-purple-800',
  'maths': 'from-purple-500/20 to-purple-600/5 border-purple-200 dark:border-purple-800',
  'science': 'from-cyan-500/20 to-cyan-600/5 border-cyan-200 dark:border-cyan-800',
  'biology': 'from-green-500/20 to-green-600/5 border-green-200 dark:border-green-800',
  'hindi': 'from-red-500/20 to-red-600/5 border-red-200 dark:border-red-800',
  'english': 'from-indigo-500/20 to-indigo-600/5 border-indigo-200 dark:border-indigo-800',
};

export default function SubjectsPage() {
  const { classId } = useParams();
  const [subjects, setSubjects] = useState([]);
  const [classInfo, setClassInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [classId]);

  const fetchData = async () => {
    try {
      const [subjectsRes, classesRes] = await Promise.all([
        subjectAPI.getByClass(classId),
        classAPI.getAll()
      ]);
      setSubjects(subjectsRes.data);
      const foundClass = classesRes.data.find(c => c.id === classId);
      setClassInfo(foundClass);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSubjectIcon = (name) => {
    const lowerName = name.toLowerCase();
    const IconComponent = subjectIconMap[lowerName];
    return IconComponent || BookText;
  };

  const getSubjectColor = (name) => {
    const lowerName = name.toLowerCase();
    return subjectColorMap[lowerName] || 'from-gray-500/20 to-gray-600/5 border-gray-200 dark:border-gray-800';
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link to="/" className="hover:text-foreground transition-colors" data-testid="breadcrumb-home">
            Home
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground font-medium">
            {classInfo?.name || `Class ${classId}`}
          </span>
        </nav>

        {/* Header */}
        <div className="mb-10">
          <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
            {classInfo?.name || `Class ${classId}`}
          </h1>
          <p className="text-muted-foreground">
            Select a subject to view chapters and questions
          </p>
        </div>

        {/* Subjects Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-48 rounded-2xl" />
            ))}
          </div>
        ) : subjects.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <p className="text-muted-foreground text-lg mb-2">No subjects available yet</p>
            <p className="text-sm text-muted-foreground">
              Ask admin to add subjects for this class
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {subjects.map((subject, index) => {
              const IconComponent = getSubjectIcon(subject.name);
              return (
                <Link
                  key={subject.id}
                  to={`/class/${classId}/subject/${subject.id}`}
                  className={`subject-card h-48 flex flex-col justify-between p-6 rounded-2xl border bg-gradient-to-br ${getSubjectColor(subject.name)} animate-slide-up`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                  data-testid={`subject-card-${subject.id}`}
                >
                  <div className="w-12 h-12 rounded-xl bg-background/80 flex items-center justify-center shadow-md">
                    <IconComponent className="w-6 h-6 text-primary" />
                  </div>
                  
                  <div>
                    <h3 className="font-heading text-xl font-semibold text-foreground mb-1">
                      {subject.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{subject.name_hi}</p>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
