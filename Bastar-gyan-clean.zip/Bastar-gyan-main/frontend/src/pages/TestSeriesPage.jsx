import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { classAPI, subjectAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { ClipboardList, ChevronRight, BookOpen, Award, GraduationCap } from 'lucide-react';

const classIcons = {
  '10': BookOpen,
  '11': GraduationCap,
  '12': Award,
};

export default function TestSeriesPage() {
  const [classes, setClasses] = useState([]);
  const [subjectsByClass, setSubjectsByClass] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const classesRes = await classAPI.getAll();
      setClasses(classesRes.data);
      
      // Fetch subjects for each class
      const subjectsMap = {};
      for (const cls of classesRes.data) {
        const subjectsRes = await subjectAPI.getByClass(cls.id);
        subjectsMap[cls.id] = subjectsRes.data;
      }
      setSubjectsByClass(subjectsMap);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
            <ClipboardList className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
            Test Series
          </h1>
          <p className="text-muted-foreground">
            Practice MCQs and Mock Tests with Detailed Analysis
          </p>
        </div>

        {/* Classes with Subjects */}
        {loading ? (
          <div className="space-y-8">
            {[1, 2, 3].map((i) => (
              <div key={i}>
                <Skeleton className="h-8 w-48 mb-4" />
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[1, 2, 3, 4].map((j) => (
                    <Skeleton key={j} className="h-24 rounded-xl" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-12">
            {classes.map((cls) => {
              const IconComponent = classIcons[cls.id] || BookOpen;
              const subjects = subjectsByClass[cls.id] || [];
              
              return (
                <div key={cls.id} className="animate-fade-in">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-primary" />
                    </div>
                    <h2 className="font-heading text-xl md:text-2xl font-semibold text-foreground">
                      {cls.name}
                    </h2>
                  </div>
                  
                  {subjects.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8 bg-muted/30 rounded-xl">
                      No subjects available for test series
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {subjects.map((subject) => (
                        <Link
                          key={subject.id}
                          to={`/class/${cls.id}/subject/${subject.id}/test`}
                          className="test-card flex items-center gap-4 group"
                          data-testid={`test-card-${cls.id}-${subject.id}`}
                        >
                          <div className="flex-1">
                            <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                              {subject.name}
                            </h3>
                            <p className="text-sm text-muted-foreground">{subject.name_hi}</p>
                          </div>
                          <ChevronRight className="w-5 h-5 text-primary" />
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
