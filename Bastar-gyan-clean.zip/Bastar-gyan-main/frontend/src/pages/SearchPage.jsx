import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { searchAPI, classAPI } from '../lib/api';
import { Skeleton } from '../components/ui/skeleton';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Search, ChevronRight, FileText } from 'lucide-react';
import { getTagColorClass, truncateText } from '../lib/utils';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [classFilter, setClassFilter] = useState('all');
  const [results, setResults] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    fetchClasses();
    const q = searchParams.get('q');
    if (q) {
      setQuery(q);
      handleSearch(q);
    }
  }, []);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const handleSearch = async (searchQuery = query) => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setSearched(true);
    
    try {
      const classId = classFilter === 'all' ? null : classFilter;
      const response = await searchAPI.search(searchQuery.trim(), classId);
      setResults(response.data);
      setSearchParams({ q: searchQuery.trim() });
    } catch (error) {
      console.error('Error searching:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleSearch();
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
            Search Questions
          </h1>
          <p className="text-muted-foreground">
            Find any question across all subjects and chapters
          </p>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSubmit} className="mb-10">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for questions... / प्रश्न खोजें..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-12 h-12 text-lg"
                data-testid="search-input-main"
              />
            </div>
            
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-full md:w-48 h-12" data-testid="class-filter-select">
                <SelectValue placeholder="All Classes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>
                    {cls.name_hi}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button type="submit" size="lg" className="h-12 px-8" data-testid="search-submit-btn">
              Search
            </Button>
          </div>
        </form>

        {/* Results */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-24 rounded-xl" />
            ))}
          </div>
        ) : searched && results.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg mb-2">No results found</p>
            <p className="text-sm text-muted-foreground">
              Try searching with different keywords
            </p>
          </div>
        ) : results.length > 0 && (
          <div>
            <p className="text-muted-foreground mb-4">{results.length} results found</p>
            <div className="space-y-4">
              {results.map((question, index) => (
                <Link
                  key={question.id}
                  to={`/question/${question.id}`}
                  className="question-card block p-5 rounded-xl border bg-card animate-slide-up"
                  style={{ animationDelay: `${index * 0.05}s` }}
                  data-testid={`search-result-${question.id}`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          Class {question.class_id}
                        </Badge>
                        {question.tags?.map((tag, i) => (
                          <Badge key={i} variant="secondary" className={getTagColorClass(tag)}>
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <h3 className="font-medium text-foreground mb-1" lang="hi">
                        {truncateText(question.question_hi || question.question, 150)}
                      </h3>
                      {question.question_hi && question.question && (
                        <p className="text-sm text-muted-foreground">
                          {truncateText(question.question, 100)}
                        </p>
                      )}
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
