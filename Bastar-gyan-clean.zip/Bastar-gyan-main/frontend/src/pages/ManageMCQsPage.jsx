import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { mcqAPI, classAPI, subjectAPI, chapterAPI } from '../lib/api';
import { Button } from '../components/ui/button';
import { Skeleton } from '../components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Edit, Trash2, ClipboardList, Search } from 'lucide-react';
import { Input } from '../components/ui/input';
import { truncateText } from '../lib/utils';

export default function ManageMCQsPage() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [mcqs, setMcqs] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chapters, setChapters] = useState([]);
  
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedChapter, setSelectedChapter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/admin/login');
    } else if (isAuthenticated) {
      fetchClasses();
    }
  }, [isAuthenticated, authLoading, navigate]);

  useEffect(() => {
    if (selectedClass) {
      fetchSubjects(selectedClass);
      setSelectedSubject('');
      setSelectedChapter('');
      setChapters([]);
      setMcqs([]);
    }
  }, [selectedClass]);

  useEffect(() => {
    if (selectedSubject) {
      fetchChapters(selectedSubject);
      setSelectedChapter('');
      setMcqs([]);
    }
  }, [selectedSubject]);

  useEffect(() => {
    if (selectedChapter) {
      fetchMcqs(selectedChapter);
    }
  }, [selectedChapter]);

  const fetchClasses = async () => {
    try {
      const response = await classAPI.getAll();
      setClasses(response.data);
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubjects = async (classId) => {
    try {
      const response = await subjectAPI.getByClass(classId);
      setSubjects(response.data);
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const fetchChapters = async (subjectId) => {
    try {
      const response = await chapterAPI.getBySubject(subjectId);
      setChapters(response.data);
    } catch (error) {
      console.error('Error fetching chapters:', error);
    }
  };

  const fetchMcqs = async (chapterId) => {
    setLoading(true);
    try {
      const response = await mcqAPI.getByChapter(chapterId);
      setMcqs(response.data);
    } catch (error) {
      console.error('Error fetching MCQs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (mcqId) => {
    if (!window.confirm('Are you sure you want to delete this MCQ?')) return;
    
    setDeleting(mcqId);
    try {
      await mcqAPI.delete(mcqId);
      toast.success('MCQ deleted successfully');
      setMcqs(mcqs.filter(m => m.id !== mcqId));
    } catch (error) {
      console.error('Error deleting MCQ:', error);
      toast.error('Failed to delete MCQ');
    } finally {
      setDeleting(null);
    }
  };

  const filteredMcqs = mcqs.filter(m => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      m.question?.toLowerCase().includes(query) ||
      m.question_hi?.toLowerCase().includes(query)
    );
  });

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/dashboard')} data-testid="back-btn">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-heading text-2xl font-bold text-foreground">Manage MCQs</h1>
              <p className="text-muted-foreground">View, edit, and delete MCQs</p>
            </div>
          </div>
          <Link to="/admin/mcqs/add">
            <Button className="flex items-center gap-2" data-testid="add-new-mcq-btn">
              <Plus className="w-4 h-4" />
              Add New MCQ
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="bg-card rounded-xl border p-6 mb-6">
          <h2 className="font-medium text-foreground mb-4">Filter MCQs</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger data-testid="filter-mcq-class-select">
                <SelectValue placeholder="Select Class" />
              </SelectTrigger>
              <SelectContent>
                {classes.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedSubject} onValueChange={setSelectedSubject} disabled={!selectedClass}>
              <SelectTrigger data-testid="filter-mcq-subject-select">
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subj) => (
                  <SelectItem key={subj.id} value={subj.id}>{subj.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedChapter} onValueChange={setSelectedChapter} disabled={!selectedSubject}>
              <SelectTrigger data-testid="filter-mcq-chapter-select">
                <SelectValue placeholder="Select Chapter" />
              </SelectTrigger>
              <SelectContent>
                {chapters.map((chap) => (
                  <SelectItem key={chap.id} value={chap.id}>{chap.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search MCQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-mcqs-input"
              />
            </div>
          </div>
        </div>

        {/* MCQs List */}
        {!selectedChapter ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <ClipboardList className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Select a class, subject, and chapter to view MCQs</p>
          </div>
        ) : loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32 rounded-xl" />
            ))}
          </div>
        ) : filteredMcqs.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <ClipboardList className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No MCQs found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMcqs.map((mcq) => (
              <div
                key={mcq.id}
                className="bg-card rounded-xl border p-5 hover:border-primary/30 transition-colors"
                data-testid={`mcq-item-${mcq.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground mb-2">
                      {truncateText(mcq.question || mcq.question_hi, 150)}
                    </h3>
                    {mcq.question_hi && mcq.question && (
                      <p className="text-sm text-muted-foreground mb-3" lang="hi">
                        {truncateText(mcq.question_hi, 100)}
                      </p>
                    )}
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {mcq.options?.slice(0, 4).map((opt, i) => (
                        <div 
                          key={i} 
                          className={`p-2 rounded ${i === mcq.correct_option_index ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300' : 'bg-muted'}`}
                        >
                          {String.fromCharCode(65 + i)}. {truncateText(opt.text || opt.text_hi, 30)}
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Link to={`/admin/mcqs/edit/${mcq.id}`}>
                      <Button variant="outline" size="sm" className="flex items-center gap-1" data-testid={`edit-mcq-${mcq.id}`}>
                        <Edit className="w-4 h-4" />
                        Edit
                      </Button>
                    </Link>
                    <Button 
                      variant="destructive" 
                      size="sm" 
                      className="flex items-center gap-1"
                      onClick={() => handleDelete(mcq.id)}
                      disabled={deleting === mcq.id}
                      data-testid={`delete-mcq-${mcq.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                      {deleting === mcq.id ? 'Deleting...' : 'Delete'}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
